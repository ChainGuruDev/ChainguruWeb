const mongoose = require("mongoose");
var Schema = mongoose.Schema;
const ObjectID = require("mongodb").ObjectID;

const MovementsSchema = mongoose.Schema({
  movements: {
    _id: ObjectID,
    wallet: String,
    operation: String,
    tokenContract: String,
    tokenSymbol: String,
    timeStamp: Number,
    value: Number,
    tokenDecimal: Number,
    buyPrice: {
      usd: Number,
      eur: Number,
      btc: Number,
      eth: Number,
    },
    gasUsed: Number,
    gasPrice: Number,
    type: Array,
  },
});

module.exports = mongoose.model("Movements", MovementsSchema);
