const mongoose = require("mongoose");
var Schema = mongoose.Schema;

const TokenSchema = mongoose.Schema({
  tokenID: {
    type: String,
  },
  name: {
    type: String,
    required: true,
  },
  symbol: {
    type: String,
    required: true,
  },
  categories: {
    type: Array,
  },
});

module.exports = mongoose.model("Tokens", TokenSchema);
