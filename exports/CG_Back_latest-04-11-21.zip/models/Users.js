const mongoose = require("mongoose");
var Schema = mongoose.Schema;
const Wallet = require("./Wallet");
const Favorites = require("./Favorites");
const Blacklist = require("./Blacklist");
const BlueChips = require("./BlueChips");

const UsersSchema = mongoose.Schema({
  user: {
    type: String,
    required: true,
    unique: true,
  },
  nonce: {
    allowNull: false,
    type: Number,
    default: Math.floor(Math.random() * 10000000),
    required: true,
  },
  nonceCreated: {
    type: Date,
    required: true,
    default: Date.now,
  },
  wallets: [
    { type: Schema.Types.ObjectId, ref: "Wallets", autopopulate: true },
  ],
  favorites: {
    type: Schema.Types.ObjectId,
    ref: "Favorites",
    autopopulate: true,
  },
  blacklist: {
    type: Schema.Types.ObjectId,
    ref: "Blacklist",
    autopopulate: true,
  },
  nickname: {
    type: String,
  },
  avatar: {
    type: String,
  },
  experiencePoints: {
    type: Number,
  },
  minigames: {
    longShortStrike: {
      long: {
        type: Number,
        default: 0,
      },
      short: {
        type: Number,
        default: 0,
      },
    },
  },
  walletNicknames: [
    {
      wallet: String,
      nickname: String,
    },
  ],
  blueChips: {
    type: Schema.Types.ObjectId,
    ref: "BlueChips",
    autopopulate: true,
  },
});

UsersSchema.plugin(require("mongoose-autopopulate"));
module.exports = mongoose.model("Users", UsersSchema);
