const mongoose = require("mongoose");
var Schema = mongoose.Schema;

const BlueChipsSchema = mongoose.Schema({
  tokenIDs: {
    type: Array,
  },
});

module.exports = mongoose.model("BlueChips", BlueChipsSchema);
