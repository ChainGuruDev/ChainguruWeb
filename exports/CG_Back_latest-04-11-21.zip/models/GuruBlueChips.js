const mongoose = require("mongoose");
var Schema = mongoose.Schema;

const GuruBlueChipsSchema = mongoose.Schema({
  tokenIDs: {
    type: Array,
  },
});

module.exports = mongoose.model("GuruBlueChips", GuruBlueChipsSchema);
