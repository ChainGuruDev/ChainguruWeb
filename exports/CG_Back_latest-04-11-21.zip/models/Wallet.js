const mongoose = require("mongoose");
var Schema = mongoose.Schema;

const WalletSchema = mongoose.Schema({
  wallet: {
    type: String,
  },
  lastUpdated: { type: Date },
});

// WalletSchema.plugin(require("mongoose-autopopulate"));
module.exports = mongoose.model("Wallets", WalletSchema);
