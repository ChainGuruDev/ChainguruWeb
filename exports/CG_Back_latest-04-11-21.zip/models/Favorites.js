const mongoose = require("mongoose");
var Schema = mongoose.Schema;

const FavoritesSchema = mongoose.Schema({
  tokenIDs: {
    type: Array,
  },
});

module.exports = mongoose.model("Favorites", FavoritesSchema);
