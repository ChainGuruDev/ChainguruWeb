const mongoose = require("mongoose");
var Schema = mongoose.Schema;

const BlacklistSchema = mongoose.Schema({
  tokenIDs: {
    type: Array,
  },
});

module.exports = mongoose.model("Blacklist", BlacklistSchema);
