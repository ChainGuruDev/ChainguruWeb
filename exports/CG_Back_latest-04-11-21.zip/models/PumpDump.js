const mongoose = require("mongoose");
var Schema = mongoose.Schema;
const ObjectID = require("mongodb").ObjectID;

const PumpDumpSchema = mongoose.Schema({
  user: {
    type: String,
    required: true,
  },
  tokenID: {
    type: String,
    required: true,
  },
  vote: {
    type: Boolean,
    required: true,
  },
  voteEnding: {
    type: Date,
    required: true,
  },
  priceStart: {
    type: Number,
    required: true,
  },
  priceEnd: {
    type: Number,
  },
  complete: {
    type: Boolean,
    default: false,
  },
  result: {
    type: Boolean,
    required: false,
  },
});

mongoose.Schema.Types.Boolean.convertToTrue.add("pump");
mongoose.Schema.Types.Boolean.convertToFalse.add("dump");
mongoose.Schema.Types.Boolean.convertToTrue.add("long");
mongoose.Schema.Types.Boolean.convertToFalse.add("short");

module.exports = mongoose.model("PumpDump", PumpDumpSchema);
