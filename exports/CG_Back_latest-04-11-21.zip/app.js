const express = require("express");
const app = express();
const mongoose = require("mongoose");
const bodyParser = require("body-parser");
const cookieParser = require("cookie-parser");
const cors = require("cors");
require("dotenv/config");
var allowlist = [
  "https://chainguru.app",
  "https://chainguru-dev.herokuapp.com",
  "https://192.168.1.50:3000",
  "https://192.168.1.54:3000",
];
var corsOptions = {
  origin: allowlist,
  optionsSuccessStatus: 200, // some legacy browsers (IE11, various SmartTVs) choke on 204
  credentials: true,
  exposedHeaders: ["set-cookie"],
  methods: "POST,PUT,DELETE",
};

//Middlewares
app.options(cors(corsOptions));
app.use(cors(corsOptions));
app.use(cookieParser());
//DISABLE FOR DEBUGGING

app.use(bodyParser.json());

//Import Routes
const authRoute = require("./routes/auth");
const usersRoute = require("./routes/users");
const walletRoute = require("./routes/wallet");
const favoritesRoute = require("./routes/favorites");
const movementsRoute = require("./routes/movements");
const blacklistRoute = require("./routes/blacklist");
const tokensRoute = require("./routes/tokens");

const longShortRoute = require("./routes/longShort");
const pumpDumpRoute = require("./routes/pumpDump");
const gasRoute = require("./routes/gas");

const guruBlueChipsRoute = require("./routes/guruBluechips.js");
const blueChipsRoute = require("./routes/bluechips.js");

const zerionRoute = require("./routes/zerion.js");

app.use("/auth", authRoute);
app.use("/users", usersRoute);
app.use("/wallets", walletRoute);
app.use("/favorites", favoritesRoute);
app.use("/movements", movementsRoute);
app.use("/blacklist", blacklistRoute);
app.use("/tokens", tokensRoute);
app.use("/longShort", pumpDumpRoute);
app.use("/gas", gasRoute);
app.use("/blueChips/user", blueChipsRoute);
app.use("/blueChips/guru", guruBlueChipsRoute);
app.use("/zerion", zerionRoute);

//ROUTES

app.get("/", (req, res) => {
  res.send("ChainguruDB HOME");
});

//connect to DB
mongoose.connect(
  process.env.DB_CONNECTION,
  { useNewUrlParser: true, useUnifiedTopology: true },
  () => console.log("Connected to DB")
);

mongoose.set("useCreateIndex", true);
app.listen(process.env.PORT || 3001);
