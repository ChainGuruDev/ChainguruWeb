const jwt = require("jsonwebtoken");
require("dotenv/config");

var authenticateJWT = function (req, res, next) {
  const authHeader = req.headers.authorization;
  if (authHeader) {
    const token = authHeader.split(" ")[1];
    jwt.verify(token, process.env.JWTPRIVATEKEY, (err, data) => {
      if (err) {
        console.log(err);
        return res.sendStatus(403);
      }
      const reqUser = req.params.userID ? req.params.userID : req.body.user;
      if (reqUser === data.payload.user) {
        console.log("valid access token");
        next();
      } else {
        // console.log("not a valid access token for this user");
        res.sendStatus(401);
      }
    });
  } else {
    res.sendStatus(401);
  }
};

module.exports = { authenticateJWT };
