te paso todo justin case, pero lo importante esta en
routes > wallet.js

y ahi las importantes son:

linea 441 aprox
router.put("/updateOne", async (req, res) => {

Con esta saco las ERC20 token transfer TX de etherscan y actualizo las grabadas en la base de datos local

Aca tendria q ir a la linea 80
esta todo comentado
router.put("/movements", async (req, res) => {
aca en base a esas transacciones que filtre antes y me quedaron locales, voy una por una y le voy pidiendo a coingecko el precio del token lo mas cerca al timestamp posible.
tengo un contador que cada 10 pedidos mete un sleep forzado para no reventar a gecko
en teoria cuando terminaba de hacer todo lo actualizaba en la DB para que no haya que hacerlo ooootra vez
como esto no lo habia logrado hacer andar sin que reviente a gecko o sin que tarde un monton de tiempo y me termine tirando un timeout lo tengo todo desactivado


(ASI ESTA FUNCIONANDO EN EL SITIO HOY)
despues cuando me llega esa respuesta llamo a
linea 193
router.put("/balance", async (req, res) => {

armo un array vacio donde voy a poner cada token y su balance
aca voy acomodando las transacciones una por una, filtro las de uniswap y otra SUB q me hinchaba los huevos para q las busque por su contrato
y voy actualizando este array con el balance de cada moneda,
si fue una compra o venta le voy sumando o restando el balance
una vez q hice esto con todas las transacciones le devuelvo al sitio el listado de balance erc20 actualizado, y desde el sitio pido a coingecko todos los precios actuales de esas monedas...
no tengo el precio por cada transaccion y por eso no puedo sacar el precio promedio y el nivel de profit.