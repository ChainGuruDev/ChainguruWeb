const Bottleneck = require("bottleneck");
const express = require("express");
const router = express.Router();
const Tokens = require("../models/Tokens");
require("dotenv/config");
const axios = require("axios").default;
const cors = require("cors");

const limiterGAS = new Bottleneck({
  minTime: 500,
  maxConcurrent: 1,
});

checkGasPrice = async () => {
  try {
    const etherScanAPI = process.env.ETHERSCAN_API;
    const _url = `https://api.etherscan.io/api?module=gastracker&action=gasoracle&apikey=${etherScanAPI}`;
    // console.log(_url);
    const geckolist = await axios.get(_url);
    return geckolist.data;
  } catch (err) {
    res.json({ message: err.message });
  }
};

// router.options(cors(corsOptions));
router.get("/checkGas", async (req, res) => {
  try {
    const wrappedGas = limiterGAS.wrap(checkGasPrice);
    const result = await wrappedGas();
    res.json(result);
  } catch (err) {
    res.json({ message: err.message });
  }
});

module.exports = router;
