const express = require("express");
const router = express.Router();
const GuruBlueChips = require("../models/GuruBlueChips");
const { authenticateJWT } = require("../extras/verifyJWT.js");

router.get("/", async (req, res) => {
  try {
    const blueChips = await GuruBlueChips.find();
    res.json(blueChips);
  } catch (err) {
    res.json({ message: err.message });
  }
});

//ADD TOKEN TO FAVORITES
router.post("/check", authenticateJWT, async (req, res) => {
  try {
    if (
      req.body.from === process.env.ADMIN_ACC_GURU ||
      req.body.from === process.env.ADMIN_ACC
    ) {
      res.json(true);
    } else {
      res.json(false);
    }
  } catch (err) {
    res.json({ message: err.message });
  }
});

//ADD TOKEN TO FAVORITES
router.post("/", authenticateJWT, async (req, res) => {
  try {
    if (
      req.body.from === process.env.ADMIN_ACC_GURU ||
      req.body.from === process.env.ADMIN_ACC
    ) {
      const updatedBlueChips = await GuruBlueChips.updateOne(
        {},
        {
          $addToSet: {
            tokenIDs: req.body.tokenID,
          },
        },
        { upsert: true, new: true, useFindAndModify: false }
      );
      res.json(updatedBlueChips);
    } else {
      res.json({ message: "you are not a guru" });
    }
  } catch (err) {
    res.json({ message: err.message });
  }
});

router.delete("/", authenticateJWT, async (req, res) => {
  try {
    if (
      req.body.from === process.env.ADMIN_ACC_GURU ||
      req.body.from === process.env.ADMIN_ACC
    ) {
      const updatedBlueChips = await GuruBlueChips.updateOne(
        {},
        {
          $pull: {
            tokenIDs: req.body.tokenID,
          },
        },
        { upsert: true, new: true, useFindAndModify: false }
      );
      res.json(updatedBlueChips);
    } else {
      res.json({ message: "you are not a guru" });
    }
  } catch (err) {
    res.json({ message: err.message });
  }
});

module.exports = router;
