const express = require("express");
const router = express.Router();
const PumpDump = require("../models/PumpDump");
const Users = require("../models/Users");

const axios = require("axios").default;

geckoGetCurrentPrice = async (tokenID) => {
  try {
    const _url = `https://api.coingecko.com/api/v3/simple/price?ids=${tokenID}&vs_currencies=usd`;
    // console.log(_url);
    const geckolist = await axios.get(_url);
    return geckolist.data;
  } catch (err) {
    res.json({ message: err.message });
  }
};

geckoGetPriceAtTime = async (tokenID, from, to) => {
  try {
    const _url = `https://api.coingecko.com/api/v3/coins/${tokenID}/market_chart/range?vs_currency=usd&from=${from}&to=${to}`;
    // console.log(_url);
    const geckolist = await axios.get(_url);
    // console.log(geckolist.data.prices[0][1]);
    return geckolist.data.prices[0][1];
  } catch (err) {
    res.json({ message: err.message });
  }
};

//GET ALL longShorts
router.get("/all", async (req, res) => {
  try {
    if (req.query.onlyActive === "true") {
      const longShorts = await PumpDump.find({ complete: false });
      res.json(longShorts);
    } else {
      const longShorts = await PumpDump.find();
      res.json(longShorts);
    }
  } catch (err) {
    res.json({ message: err.message });
  }
});

router.get("/token", async (req, res) => {
  try {
    if (req.query.onlyActive === "false") {
      if (req.query.userID) {
        const tokenPDs = await PumpDump.find({
          tokenID: req.query.tokenID,
          user: req.query.userID,
        }).exec();
        res.json(tokenPDs);
      } else {
        const tokenPDs = await PumpDump.find({
          tokenID: req.query.tokenID,
        }).exec();
        res.json(tokenPDs);
      }
    } else {
      if (req.query.userID) {
        const tokenPDs = await PumpDump.find({
          tokenID: req.query.tokenID,
          complete: false,
          user: req.query.userID,
        }).exec();
        res.json(tokenPDs);
      } else {
        const tokenPDs = await PumpDump.find({
          tokenID: req.query.tokenID,
          complete: false,
        }).exec();
        res.json(tokenPDs);
      }
    }
  } catch (err) {
    res.json(err);
  }
});

router.get("/user", async (req, res) => {
  try {
    if (req.query.onlyActive === "true") {
      const allUserPDs = await PumpDump.find({
        user: req.query.userID,
        complete: false,
      }).exec();
      res.json(allUserPDs);
    } else {
      const userActivePDs = await PumpDump.find({
        user: req.query.userID,
      }).exec();
      res.json(userActivePDs);
    }
  } catch (err) {
    res.json(err);
  }
});

//CREATE NEW LongShort
//Check if user has a running LongShort with current tokenID,
// else create a new one;
router.put("/new", async (req, res) => {
  const userLongShort = await PumpDump.find({
    user: req.body.user,
    tokenID: req.body.tokenID,
  }).exec();
  const activeLS = await PumpDump.find({
    user: req.body.user,
    complete: false,
  }).exec();
  const tokenID = req.body.tokenID;
  const currentPrice = await geckoGetCurrentPrice(tokenID);
  if (activeLS.length < 7) {
    const newPD = new PumpDump({
      user: req.body.user,
      tokenID: req.body.tokenID,
      vote: req.body.vote,
      priceStart: currentPrice[tokenID].usd,
      // voteEnding: Date.now() + 120 * 1000, // 60 seconds from now for test reasons
      // voteEnding: Date.now() + 12 * 60 * 60 * 1000, // 12 hours from now
      voteEnding: Date.now() + 24 * 60 * 60 * 1000, // 24 hours from now
    });

    if (userLongShort.length != 0) {
      if (userLongShort[userLongShort.length - 1].complete === false) {
        res.json(userLongShort[userLongShort.length - 1]);
      } else {
        newPD.save().then(() => res.json(newPD));
      }
    } else {
      newPD.save().then(() => res.json(newPD));
    }
  } else {
    res.json({ message: "maximum reached", error: true });
  }
});

router.put("/checkResult", async (req, res) => {
  try {
    const date = new Date(Date.now());

    //Find latest user P&D for tokenID
    const longShort = await PumpDump.find({
      user: req.body.user,
      tokenID: req.body.tokenID,
      complete: false,
    }).exec();
    if (longShort.length != 0) {
      //if there's an active one check for currentTime > voteEnding
      const oldPD = longShort[longShort.length - 1];
      if (date.getTime() > oldPD.voteEnding.getTime()) {
        // console.log("new time");
        //reformat TIME IN SECONDS not mili for coingecko request
        shortFromTime =
          (oldPD.voteEnding.getTime() - (oldPD.voteEnding.getTime() % 1000)) /
          1000;
        shortToTime = (date.getTime() - (date.getTime() % 1000)) / 1000;
        //Query price data from coingecko
        // console.log("query gecko");
        const priceEnd = await geckoGetPriceAtTime(
          req.body.tokenID,
          shortFromTime,
          shortToTime
        );

        let oldPD_result = oldPD.vote
          ? priceEnd > oldPD.priceStart
            ? true
            : false
          : priceEnd < oldPD.priceStart
          ? true
          : false;

        const updatedPD = await PumpDump.findByIdAndUpdate(
          oldPD.id,
          {
            $set: {
              priceStart: oldPD.priceStart,
              priceEnd: priceEnd,
              result: oldPD.vote
                ? priceEnd > oldPD.priceStart
                  ? true
                  : false
                : priceEnd < oldPD.priceStart
                ? true
                : false,
              complete: true,
            },
          },
          {
            upsert: true,
            new: true,
            useFindAndModify: false,
          }
        );
        //FIND CURRENT USER TO GET PREVIOUS DATA
        const user = await Users.findOne({ user: req.body.user });
        //START WITH STRIKE 0
        let voteStrikeLong = 0;
        let voteStrikeShort = 0;
        //UPDATE CURRENT STRIKE IF USER HAS ALREADY
        if (user.minigames.longShortStrike.long) {
          voteStrikeLong = user.minigames.longShortStrike.long;
        }
        if (user.minigames.longShortStrike.short) {
          voteStrikeShort = user.minigames.longShortStrike.short;
        }

        //VOTE CORRECT RESULT
        if (oldPD_result) {
          if (oldPD.vote) {
            voteStrikeLong += 1;
          } else {
            voteStrikeShort += 1;
          }
          let oldPoints = 0;
          //UPDATE EXP POINTS WITH CURRENT USER POINTS
          if (user.experiencePoints != null) {
            console.log("TESTING EXP POINTS");
            console.log(user.experiencePoints);
            oldPoints = user.experiencePoints;
          }
          //ADD 50 POINTS FOR RIGHT ANSWER
          oldPoints += 50;

          //CHECK FOR VOTING STRIKES >> IF STRIKES === 7 ADD DOUBLE THE POINTS (7*50 = 350)
          if (oldPD.vote) {
            if (voteStrikeLong > 7) {
              oldPoints += 50;
            }
            if (voteStrikeLong === 7) {
              oldPoints += 350;
            }
            let newUser = await Users.findByIdAndUpdate(
              user._id,
              {
                $set: {
                  experiencePoints: oldPoints,
                  minigames: {
                    longShortStrike: {
                      long: voteStrikeLong,
                      short: voteStrikeShort,
                    },
                  },
                },
              },
              { upsert: true, new: true, useFindAndModify: false }
            );
          } else {
            if (voteStrikeShort > 7) {
              oldPoints += 50;
            }
            if (voteStrikeShort === 7) {
              oldPoints += 350;
            }
            let newUser = await Users.findByIdAndUpdate(
              user._id,
              {
                $set: {
                  experiencePoints: oldPoints,
                  minigames: {
                    longShortStrike: {
                      long: voteStrikeLong,
                      short: voteStrikeShort,
                    },
                  },
                },
              },
              { upsert: true, new: true, useFindAndModify: false }
            );
          }
        } else {
          if (oldPD.vote) {
            let newUser = await Users.findByIdAndUpdate(
              user._id,
              {
                $set: {
                  minigames: {
                    longShortStrike: {
                      long: 0,
                      short: voteStrikeShort,
                    },
                  },
                },
              },
              { upsert: true, new: true, useFindAndModify: false }
            );
          } else {
            let newUser = await Users.findByIdAndUpdate(
              user._id,
              {
                $set: {
                  minigames: {
                    longShortStrike: {
                      long: voteStrikeLong,
                      short: 0,
                    },
                  },
                },
              },
              { upsert: true, new: true, useFindAndModify: false }
            );
          }
        }

        res.json(updatedPD);
      } else {
        res.json({ error: "voting time not complete" });
      }
    } else {
      res.json(longShort);
    }
  } catch (err) {
    res.json({ message: err.message });
  }
});

//CALCULATE USER SCORE BASED ON COMPLETE Short&Longs
router.get("/getScores", async (req, res) => {
  try {
    let users = [];
    const longShorts = await PumpDump.find({ complete: true });
    longShorts.forEach((item, i) => {
      let index = users
        .map(function (e) {
          return e.user;
        })
        .indexOf(item.user);
      if (index == -1) {
        if (item.result) {
          let newUser = { user: item.user, points: 50 };
          users.push(newUser);
        } else {
          let newUser = { user: item.user, points: 0 };
          users.push(newUser);
        }
      } else {
        if (item.result) {
          let newPoints = (users[index].points += 50);
          users[index] = { user: item.user, points: newPoints };
        }
      }
    });
    res.json(users);
  } catch (err) {
    res.json({ message: err.message });
  }
});
//UPDATE DB USER SCORES FROM COMPLETED LS
// router.put("/updateScores", async (req, res) => {
//   try {
//     let users = [];
//     const longShorts = await PumpDump.find({ complete: true });
//     longShorts.forEach((item, i) => {
//       let index = users
//         .map(function (e) {
//           return e.user;
//         })
//         .indexOf(item.user);
//       console.log(index);
//       if (index == -1) {
//         if (item.result) {
//           let newUser = { user: item.user, points: 50 };
//           users.push(newUser);
//         } else {
//           let newUser = { user: item.user, points: 0 };
//           users.push(newUser);
//         }
//       } else {
//         if (item.result) {
//           let newPoints = (users[index].points += 50);
//           users[index] = { user: item.user, points: newPoints };
//         }
//       }
//     });
//     for (var i = 0; i < users.length; i++) {
//       const updatedUsers = await Users.findOneAndUpdate(
//         { user: users[i].user },
//         {
//           $set: {
//             experiencePoints: users[i].points,
//           },
//         },
//         { upsert: true, new: true, useFindAndModify: false }
//       );
//     }
//     res.json(users);
//   } catch (err) {
//     res.json({ message: err.message });
//   }
// });

//TEST FOR SCORE ADD AND STRIKE TESTS
// router.put("/tryRandomScore", async (req, res) => {
//   try {
//     console.log("Test RandomScore");
//     let random_boolean = Math.random() < 0.5;
//     let random_vote = Math.random() < 0.5;
//
//     //FIND CURRENT USER TO GET PREVIOUS DATA
//     const user = await Users.findOne({ user: req.query.user });
//
//     //START WITH STRIKE 0
//     let voteStrikeLong = 0;
//     let voteStrikeShort = 0;
//     if (user.minigames.longShortStrike.long) {
//       voteStrikeLong = user.minigames.longShortStrike.long;
//     }
//     if (user.minigames.longShortStrike.short) {
//       voteStrikeShort = user.minigames.longShortStrike.short;
//     }
//     //UPDATE CURRENT STRIKE IF USER HAS ALREADY
//
//     //CORRECT VOTING RESULT
//     if (random_boolean) {
//       //UPDATE USER STRIKE COUNT LONG OR SHORT BASED ON USER VOTE
//       if (random_vote) {
//         voteStrikeLong += 1;
//       } else {
//         voteStrikeShort += 1;
//       }
//       //RESET EXP POINTS TO 0 IN CASE USER HAS NONE
//       let oldPoints = 0;
//       //UPDATE EXP POINTS WITH CURRENT USER POINTS
//       if (user.experiencePoints != null) {
//         console.log("TESTING EXP POINTS");
//         console.log(user.experiencePoints);
//         oldPoints = user.experiencePoints;
//       }
//       //ADD 50 POINTS FOR RIGHT ANSWER
//       oldPoints += 50;
//
//       //CHECK FOR VOTING STRIKES >> IF STRIKES === 7 ADD DOUBLE THE POINTS (7*50 = 350)
//       if (random_vote) {
//         if (voteStrikeLong > 7) {
//           oldPoints += 50;
//         }
//         if (voteStrikeLong === 7) {
//           oldPoints += 350;
//         }
//       } else {
//         if (voteStrikeShort > 7) {
//           oldPoints += 50;
//         }
//         if (voteStrikeShort === 7) {
//           oldPoints += 350;
//         }
//       }
//       console.log(oldPoints);
//       if (random_vote) {
//         let newUser = await Users.findByIdAndUpdate(
//           user._id,
//           {
//             $set: {
//               experiencePoints: oldPoints,
//               minigames: {
//                 longShortStrike: {
//                   long: voteStrikeLong,
//                   short: voteStrikeShort,
//                 },
//               },
//             },
//           },
//           { upsert: true, new: true, useFindAndModify: false },
//           function (error, result) {
//             res.json(result);
//           }
//         );
//       } else {
//         let newUser = await Users.findByIdAndUpdate(
//           user._id,
//           {
//             $set: {
//               experiencePoints: oldPoints,
//               minigames: {
//                 longShortStrike: {
//                   long: voteStrikeLong,
//                   short: voteStrikeShort,
//                 },
//               },
//             },
//           },
//           { upsert: true, new: true, useFindAndModify: false },
//           function (error, result) {
//             res.json(result);
//           }
//         );
//       }
//     } else {
//       if (random_vote) {
//         let newUser = await Users.findByIdAndUpdate(
//           user._id,
//           {
//             $set: {
//               minigames: {
//                 longShortStrike: {
//                   long: 0,
//                   short: voteStrikeShort,
//                 },
//               },
//             },
//           },
//           { upsert: true, new: true, useFindAndModify: false },
//           function (error, result) {
//             res.json(result);
//           }
//         );
//       } else {
//         let newUser = await Users.findByIdAndUpdate(
//           user._id,
//           {
//             $set: {
//               minigames: {
//                 longShortStrike: {
//                   long: voteStrikeLong,
//                   short: 0,
//                 },
//               },
//             },
//           },
//           { upsert: true, new: true, useFindAndModify: false },
//           function (error, result) {
//             res.json(result);
//           }
//         );
//       }
//     }
//   } catch (err) {
//     res.json({ message: err.message });
//   }
// });

module.exports = router;
