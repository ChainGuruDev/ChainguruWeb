const express = require("express");
const router = express.Router();
const Users = require("../models/Users");
const Wallets = require("../models/Wallet");
require("dotenv/config");
const axios = require("axios").default;
var dateFormat = require("dateformat");

let _erc20Balance = [
  {
    tokenName: String,
    tokenSymbol: String,
    balance: Number,
    tokenDecimal: Number,
    contractAddress: String,
  },
];

let idContractList = [
  {
    contractAddress: String,
    id: String,
  },
];

geckoGetPriceContract = async (contractAddress, timeStamp, vsCoin) => {
  let prices = [];
  const from = parseInt(timeStamp) - 100;
  const to = parseInt(timeStamp) + 10000;
  let id = "";
  try {
    tokenIndex = idContractList.findIndex(
      (token) => token.contractAddress === contractAddress
    );
    if (tokenIndex === -1) {
      const _IDurl = `https://api.coingecko.com/api/v3/coins/ethereum/contract/${contractAddress}`;
      const geckoId = await axios.get(_IDurl);
      id = geckoId.data.id;
      idContractList.push({ contractAddress: contractAddress, id: id });
      console.log(idContractList);
    } else {
      console.log(tokenIndex);
      id = idContractList[tokenIndex].id;
    }

    console.log(id);
  } catch (err) {
    console.log(err.message);
  }

  if (id) {
    try {
      let date = new Date(parseInt(timeStamp) * 1000);

      const queryDate = `${date.getDate()}-${date.getMonth()}-${date.getFullYear()}`;
      const _url = `https://api.coingecko.com/api/v3/coins/${id}/history?date=${queryDate}`;
      const gecko = await axios.get(_url);
      const price = await gecko.data.market_data.current_price;
      prices = [price.usd, price.eur, price.btc, price.eth];
      return await prices;
    } catch (err) {
      console.log(err.message);
      console.log(prices);
      console.log(contractAddress);
      return prices;
    }
  }
  return prices;
};

function sleep(duration) {
  console.log(`waiting ${duration}`);
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve();
    }, duration * 1000);
  });
}
/* UPDATE MOVEMENTS
router.put("/movements", async (req, res) => {
  let movementNum = 0;
  try {
    const etherScanAPI = process.env.ETHERSCAN_API;
    const wallet = await Wallets.findOne({
      wallet: req.body.wallet,
    });
    let newMovements = [];
    let newErc20Balance = wallet.erc20Balance;

    for (var i = 0; i < wallet.transactions.length; i++) {
      let tokenIndex;
      if (wallet.transactions[i].tokenSymbol === "UNI-V2") {
        tokenIndex = newErc20Balance.findIndex(
          (token) =>
            token.contractAddress === wallet.transactions[i].contractAddress
        );
      } else if (wallet.transactions[i].tokenSymbol === "SUB") {
        tokenIndex = newErc20Balance.findIndex(
          (token) =>
            token.contractAddress === wallet.transactions[i].contractAddress
        );
      } else {
        tokenIndex = newErc20Balance.findIndex(
          (token) => token.tokenSymbol === wallet.transactions[i].tokenSymbol
        );
      }

      if (newErc20Balance[tokenIndex].movements) {
        newErc20Balance[tokenIndex].movements.length = 0;
      }

      if (movementNum > 10) {
        await sleep(10);
        movementNum = 0;
      }
      console.log(movementNum);
      console.log("          ");
      const geckoPrice = await geckoGetPriceContract(
        wallet.transactions[i].contractAddress,
        wallet.transactions[i].timeStamp
      );
      console.log(geckoPrice);
      movementNum++;

      if (wallet.transactions[i].to === req.body.wallet.toLowerCase()) {
        let newOperation = {
          operation: "BUY",
          timeStamp: wallet.transactions[i].timeStamp,
          value: wallet.transactions[i].value,
          price: geckoPrice,
        };
        let newErc = newErc20Balance[tokenIndex];
        if (!newErc20Balance[tokenIndex].movements) {
          newErc20Balance[tokenIndex].movements = [];
          newErc20Balance[tokenIndex].movements.push(newOperation);
        } else {
          newErc20Balance[tokenIndex].movements.push(newOperation);
        }
      } else if (
        wallet.transactions[i].from === req.body.wallet.toLowerCase()
      ) {
        let newOperation = {
          operation: "SELL",
          timeStamp: wallet.transactions[i].timeStamp,
          value: wallet.transactions[i].value,
          price: geckoPrice,
        };
        let newErc = newErc20Balance[tokenIndex];
        if (!newErc20Balance[tokenIndex].movements) {
          newErc20Balance[tokenIndex].movements = [];
          newErc20Balance[tokenIndex].movements.push(newOperation);
        } else {
          newErc20Balance[tokenIndex].movements.push(newOperation);
        }
      }
    }
    //console.log(newErc20Balance);
    console.log("UPDATING BALANCE DB");
    const updateWallet = await Wallets.findOneAndUpdate(
      { wallet: req.body.wallet },
      { erc20Balance: newErc20Balance },
      { upsert: true, new: true, useFindAndModify: false },
      async (error, result) => {
        if (!error) {
          if (!result) {
            result = new Wallet();
          }
          result.save(async (err, resp) => {
            if (!error) {
              res.json(result);
            } else {
              res.json({ message: err.message });
            }
          });
        } else {
          res.json({ message: error.message });
        }
      }
    );
    //res.json(newErc20Balance);
    // const updatedWallet = await Wallets.findOne({
    //   wallet: req.body.wallet,
    // });
    // res.json(updatedWallet);
  } catch (err) {
    res.json({ message: err.message });
  }
});

*/

//UPDATE ERC20 BALANCE
router.put("/balance", async (req, res) => {
  try {
    const etherScanAPI = process.env.ETHERSCAN_API;
    const wallet = await Wallets.findOne({
      wallet: req.body.wallet,
    });
    let newErc20Balance = [];
    for (var i = 0; i < wallet.transactions.length; i++) {
      let tokenIndex;
      if (wallet.transactions[i].tokenSymbol === "UNI-V2") {
        console.log("UNI V2 token");
        tokenIndex = newErc20Balance.findIndex(
          (token) =>
            token.contractAddress === wallet.transactions[i].contractAddress
        );
      } else if (wallet.transactions[i].tokenSymbol === "SUB") {
        tokenIndex = newErc20Balance.findIndex(
          (token) =>
            token.contractAddress === wallet.transactions[i].contractAddress
        );
      } else {
        tokenIndex = newErc20Balance.findIndex(
          (token) => token.tokenSymbol === wallet.transactions[i].tokenSymbol
        );
      }

      if (wallet.transactions[i].to === req.body.wallet.toLowerCase()) {
        // console.log(`TO TX value >> ${wallet.transactions[i].value}`);
        // console.log("BUY TX");
        // console.log(wallet.transactions[i]);

        if (tokenIndex != -1) {
          // console.log("PREV BALANCE");
          // console.log(wallet.transactions[i]);
          // console.log(newErc20Balance[tokenIndex]);

          let updatedBalance = newErc20Balance[tokenIndex];
          // console.log(updatedBalance);
          updatedBalance.balance =
            parseFloat(wallet.transactions[i].value) +
            parseFloat(updatedBalance.balance);
          // console.log("NEW BALANCE");
          // console.log(updatedBalance);

          newErc20Balance.splice(tokenIndex, 1, updatedBalance);
        } else {
          const newBalance = {
            tokenName: wallet.transactions[i].tokenName,
            tokenSymbol: wallet.transactions[i].tokenSymbol,
            balance: parseFloat(wallet.transactions[i].value),
            tokenDecimal: wallet.transactions[i].tokenDecimal,
            contractAddress: wallet.transactions[i].contractAddress,
          };
          try {
            newErc20Balance.push(newBalance);
            // console.log("NEW BALANCE");
            // console.log(newBalance);
          } catch (err) {
            console.log(err);
          }
        }
      } else if (
        wallet.transactions[i].from === req.body.wallet.toLowerCase()
      ) {
        // console.log("SELL TX");
        // console.log(wallet.transactions[i]);

        // console.log(`FROM TX value >> ${wallet.transactions[i].value}`);
        if (tokenIndex != -1) {
          let updatedBalance = newErc20Balance[tokenIndex];
          let newBalance =
            parseFloat(updatedBalance.balance) -
            parseFloat(wallet.transactions[i].value);
          if (newBalance <= 0) {
            newBalance = 0;
          }

          updatedBalance.balance = parseFloat(newBalance);
          newErc20Balance.splice(tokenIndex, 1, updatedBalance);
        } else {
          console.log(
            wallet.transactions[i].tokenSymbol + "not found in balance"
          );

          const newBalance = {
            tokenName: wallet.transactions[i].tokenName,
            tokenSymbol: wallet.transactions[i].tokenSymbol,
            balance: parseFloat(wallet.transactions[i].value),
            tokenDecimal: wallet.transactions[i].tokenDecimal,
            contractAddress: wallet.transactions[i].contractAddress,
          };
          try {
            newErc20Balance.push(newBalance);
            console.log("NEW BALANCE");
            console.log(newBalance);
          } catch (err) {
            console.log(err);
          }
        }
      }
    }
    //console.log(newErc20Balance);
    //console.log("UPDATING BALANCE DB");

    //console.log("ADDING ETH BALANCE");
    const _urlEthBalance = `https://api.etherscan.io/api?module=account&action=balance&address=${req.body.wallet}&tag=latest&apikey=${etherScanAPI}`; //${ETHERSCAN_API}
    const ethBal = await axios.get(_urlEthBalance);
    const result = await ethBal.data.result;
    //console.log(result);

    const newBalance = {
      tokenName: "Ethereum",
      tokenSymbol: "eth",
      balance: parseFloat(result),
      tokenDecimal: 18,
      contractAddress: "",
    };
    try {
      const tokenIndex = newErc20Balance.findIndex(
        (token) => token.Name === "Ethereum"
      );
      if (tokenIndex != -1) {
        // console.log("NEW BALANCE");
        // console.log(updatedBalance);
        newErc20Balance.splice(tokenIndex, 1, newBalance);
      } else {
        newErc20Balance.push(newBalance);
      }
      //console.log("NEW BALANCE");
      //console.log(newBalance);
    } catch (err) {
      console.log(err);
    }

    const updateWallet = await Wallets.findOneAndUpdate(
      { wallet: req.body.wallet },
      { erc20Balance: newErc20Balance },
      { upsert: true, new: true, useFindAndModify: false },
      async (error, result) => {
        if (!error) {
          if (!result) {
            result = new Wallet();
          }
          result.save(async (err, resp) => {
            if (!error) {
              res.json(result);
            } else {
              res.json({ message: err.message });
            }
          });
        } else {
          res.json({ message: error.message });
        }
      }
    );

    // res.json(newErc20Balance);
  } catch (err) {
    res.json({ message: err.message });
  }
});

/*
var tx = wallet.transactions.map(async (x) => {
  if (x.to === req.body.wallet.toLowerCase()) {
    console.log("BUY TX");
    if (
      wallet.erc20Balance.some(
        (balance) => balance.tokenName === x.tokenName
      )
    ) {
      console.log(x.tokenSymbol + " found in balance");
      index = wallet.erc20Balance.findIndex(
        (erc20Bal) => erc20Bal.tokenName === x.tokenName
      );
      let newBalance = wallet.erc20Balance[index];
      newBalance.balance += x.value;
      erc20Balance.splice(index, 1, newBalance);
    } else {
      console.log(x.tokenSymbol + " not found in balance");
      newBalanceItem = {
        tokenName: x.tokenName,
        tokenSymbol: x.tokenSymbol,
        balance: x.value,
        tokenDecimal: x.tokenDecimal,
        contractAddress: x.contractAddress.toLowerCase(),
      };

      const updatedWallet = await Wallets.findOneAndUpdate(
        { wallet: req.body.wallet },
        {
          $addToSet: {
            erc20Balance: newBalanceItem,
          },
        },
        { upsert: true, new: true, useFindAndModify: false }
      );
    }
  } else if (x.from === req.body.wallet.toLowerCase()) {
    console.log("SELL TX");
    if (
      wallet.erc20Balance.some(
        (balance) => balance.tokenName === x.tokenName
      )
    ) {
      console.log(x.tokenSymbol + " found in balance");
      index = wallet.erc20Balance.findIndex(
        (erc20Bal) => erc20Bal.tokenName === x.tokenName
      );
      let newBalance = wallet.erc20Balance[index];
      newBalance.balance -= x.value;
      erc20Balance.splice(index, 1, newBalance);
    } else {
      console.log(x.tokenSymbol + " not found in balance");
      newBalanceItem = {
        tokenName: x.tokenName,
        tokenSymbol: x.tokenSymbol,
        balance: x.value,
        tokenDecimal: x.tokenDecimal,
        contractAddress: x.contractAddress.toLowerCase(),
      };

      const updatedWallet = await Wallets.findOneAndUpdate(
        { wallet: req.body.wallet },
        {
          $addToSet: {
            erc20Balance: newBalanceItem,
          },
        },
        { upsert: true, new: true, useFindAndModify: false },
        async (err, resp) => {
          if (!err) {
            resp.save(async (err, resp) => {
              if (!err) {
                console.log("SAVED");
              }
            });
          }
        }
      );
    }
  } else {
    console.log("UNKNOWN TX");
  }
});
*/

//UPDATE WALLET
router.put("/updateOne", async (req, res) => {
  const etherScanAPI = process.env.ETHERSCAN_API;
  const userWallet = req.body.wallet;

  //GET ALL ERC20 Token transfer TX from etherscan
  const _url = `https://api.etherscan.io/api?module=account&action=tokentx&address=${req.body.wallet}&startblock=0&endblock=999999999&sort=asc&apikey=${etherScanAPI}`;
  const erc20tx = await axios.get(_url);
  const result = await erc20tx.data.result;
  //GET CURRENT TIMESTAMP FOR UPDATE
  let _lastUpdate = await Date.now();
  //UPDATE WALLET TX stored in LocalDB with TX returned from etherscan
  const updateWallet = await Wallets.findOneAndUpdate(
    { wallet: req.body.wallet },
    { transactions: result, lastUpdated: _lastUpdate },
    { upsert: true, new: true, useFindAndModify: false },
    async (error, result) => {
      if (!error) {
        if (!result) {
          result = new Wallet();
        }
        result.save(async (err, resp) => {
          if (!error) {
            res.json(result);
          } else {
            res.json({ message: err.message });
          }
        });
      } else {
        res.json({ message: error.message });
      }
    }
  );
});

//GET ALL WALLETS
router.get("/", async (req, res) => {
  try {
    const wallets = await Wallets.find();
    res.json(wallets);
  } catch (err) {
    res.json({ message: err.message });
  }
});

//GET USER TRANSACTIONS
router.get("/transactions", async (req, res) => {
  try {
    const wallet = await Wallets.findOne({
      wallet: req.body.wallet,
    });

    let txs = wallet.transactions;

    res.json(txs);
  } catch (err) {
    res.json({ message: err.message });
  }
});

//GET USER TRANSACTIONS
router.get("/erc20balance", async (req, res) => {
  try {
    const wallet = await Wallets.findOne({
      wallet: req.body.wallet,
    });

    let erc20Bal = wallet.erc20Balance;

    res.json(erc20Bal);
  } catch (err) {
    res.json({ message: err.message });
  }
});

//GET USER WALLETS LIST
router.get("/:userID", async (req, res) => {
  try {
    const users = await Users.findOne({ user: req.params.userID });
    res.json(users.wallets);
  } catch (err) {
    res.json({ message: err.message });
  }
});

//SUBMIT A WALLET AND ADD IT TO USER LIST
router.put("/:userID", async (req, res) => {
  const newWallet = await Wallets.findOneAndUpdate(
    { wallet: req.body.address },
    { wallet: req.body.address },
    { upsert: true, new: true, useFindAndModify: false },
    function (error, result) {
      if (!error) {
        if (!result) {
          result = new Wallet();
        }
        result.save(async (err, resp) => {
          if (!error) {
            const updatedUsers = await Users.findOneAndUpdate(
              { user: req.params.userID },
              {
                $addToSet: {
                  wallets: await result._id,
                },
              },
              { upsert: true, new: true, useFindAndModify: false },
              async (err, resp) => {
                if (!err) {
                  if (!resp) {
                    resp = new Users();
                  }
                  result.save(async (err, resp) => {
                    if (!err) {
                      res.json(updatedUsers);
                    } else {
                      res.json(err.message);
                    }
                  });
                }
              }
            );
          }
        });
      }
    }
  );
});

//REMOVE WALLET FROM USER WALLETs LIST
router.delete("/:userID", async (req, res) => {
  const newWallet = await Wallets.findOne(
    { wallet: req.body.address },
    async (err, result) => {
      if (err) {
        res.json({ message: err.message });
      } else {
        try {
          const updatedUsers = await Users.findOneAndUpdate(
            { user: req.params.userID },
            {
              $pull: {
                wallets: await result._id,
              },
            },
            { new: true, useFindAndModify: false }
          );
          res.json(updatedUsers);
        } catch (err) {
          res.json({ message: err.message });
        }
      }
    }
  );
});

//SUBMIT A WALLET
router.put("/", async (req, res) => {
  const newWallet = await Wallets.findOneAndUpdate(
    { wallet: req.body.address },
    { wallet: req.body.address },
    { upsert: true, new: true, useFindAndModify: false },
    function (error, result) {
      if (!error) {
        if (!result) {
          result = new Wallet();
        }
        result.save(async (err, resp) => {
          if (!error) {
            res.json(result);
          } else {
            res.json({ message: err.message });
          }
        });
      }
    }
  );
});

//REMOVE WALLET FROM DB
router.delete("/", async (req, res) => {
  try {
    const removeWALLET = await Users.deleteOne({ wallet: req.body.address });
    res.json(removeWALLET);
  } catch (err) {
    res.json({ message: err.message });
  }
});

module.exports = router;
