const express = require("express");
const router = express.Router();
const Users = require("../models/Users");
const Movements = require("../models/Movements");
const Wallets = require("../models/Wallet");
const ObjectID = require("mongodb").ObjectID;

let _buyPrice = {
  usd: Number,
  eur: Number,
  btc: Number,
  eth: Number,
};

//GET USER MOVEMENTS
router.get("/:userID", async (req, res) => {
  try {
    const users = await Users.findOne({ user: req.params.userID });
    res.json(users.movements);
  } catch (err) {
    res.json({ message: err.message });
  }
});

//REMOVE Movement FROM MOVEMENTS
// router.delete("/:userID", async (req, res) => {
//   const user = await Users.findOne({ user: req.params.userID });
//   try {
//     const updatedFavorites = await Movements.findByIdAndUpdate(
//       user.favorites._id,
//       {
//         $pull: {
//           tokenIDs: req.body.tokenID,
//         },
//       },
//       { upsert: true, new: true, useFindAndModify: false }
//     );
//     res.json(updatedFavorites);
//   } catch (err) {
//     res.json({ message: err.message });
//   }
// });

function sleep(duration) {
  // console.log(`waiting ${duration}`);
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve();
    }, duration * 1000);
  });
}

router.put("/auto", async (req, res) => {
  let movementNum = 0;
  let newMovements = [];

  try {
    const etherScanAPI = process.env.ETHERSCAN_API;
    let user = await Users.findOne({
      user: req.body.user,
    });
    const wallet = await Wallets.findOne({
      wallet: req.body.wallet,
    });
    if (!user.movements) {
      console.log("creating new movements schema");
      userMovements = await Movements.create({
        movements: [],
      });
      // console.log("userMOVEMENTS return");
      // console.log(userMovements);
      const updatedUser = await Users.findOneAndUpdate(
        { user: req.body.user },
        {
          $set: {
            movements: userMovements._id,
          },
        },
        { upsert: true, new: true, useFindAndModify: false }
      );
      // console.log("UPDATED USERS");
      // console.log(await updatedUser);
      user = updatedUser;
    }
    const movements = await Movements.findById(user.movements._id);
    let newMovements = movements.movements;
    // console.log(newMovements);

    if (newMovements) {
      const result = newMovements.filter(
        (item) => item.wallet != req.body.wallet
      );
      newMovements = result;
    }

    for (var i = 0; i < wallet.transactions.length; i++) {
      if (wallet.transactions[i].to === req.body.wallet.toLowerCase()) {
        let newOperation = {
          _id: new ObjectID(),
          wallet: req.body.wallet,
          operation: "BUY",
          tokenContract: wallet.transactions[i].contractAddress,
          tokenName: wallet.transactions[i].tokenName,
          tokenSymbol: wallet.transactions[i].tokenSymbol,
          timeStamp: wallet.transactions[i].timeStamp,
          value: wallet.transactions[i].value,
          tokenDecimal: wallet.transactions[i].tokenDecimal,
          gasUsed: wallet.transactions[i].gasUsed,
          gasPrice: wallet.transactions[i].gasPrice,
        };
        newMovements.push(newOperation);
      } else if (
        wallet.transactions[i].from === req.body.wallet.toLowerCase()
      ) {
        let newOperation = {
          _id: new ObjectID(),
          wallet: req.body.wallet,
          operation: "SELL",
          tokenContract: wallet.transactions[i].contractAddress,
          tokenName: wallet.transactions[i].tokenName,
          tokenSymbol: wallet.transactions[i].tokenSymbol,
          timeStamp: wallet.transactions[i].timeStamp,
          value: wallet.transactions[i].value,
          tokenDecimal: wallet.transactions[i].tokenDecimal,
          gasUsed: wallet.transactions[i].gasUsed,
          gasPrice: wallet.transactions[i].gasPrice,
        };
        newMovements.push(newOperation);
      }
    }

    const updatedMovements = await Movements.findByIdAndUpdate(
      user.movements._id,
      { movements: newMovements },
      { upsert: true, new: true, useFindAndModify: false },
      async (error, result) => {
        if (!error) {
          if (!result) {
            result = new Wallet();
          }
          result.save(async (err, resp) => {
            if (!error) {
              res.json(result);
            } else {
              res.json({ message: err.message });
            }
          });
        } else {
          res.json({ message: error.message });
        }
      }
    );
  } catch (err) {
    res.json({ message: err.message });
  }
});

router.put("/addOne", async (req, res) => {
  const user = await Users.findOne({ user: req.body.userID });
  let updatedMovements;
  try {
    //SUBMIT WITH PRICE
    if (req.body.price) {
      updatedMovements = await Movements.findByIdAndUpdate(
        user.movements._id,
        {
          $addToSet: {
            movements: {
              _id: new ObjectID(),
              wallet: req.body.wallet,
              operation: req.body.operation,
              tokenContract: req.body.tokenContract,
              tokenSymbol: req.body.tokenSymbol,
              timeStamp: req.body.timeStamp,
              value: req.body.value,
              price: req.body.price,
              tokenDecimal: req.body.tokenDecimal,
              gasUsed: req.body.gasUsed,
              gasPrice: req.body.gasPrice,
            },
          },
        },
        { upsert: true, new: true, useFindAndModify: false }
      );
    } else {
      updatedMovements = await Movements.findByIdAndUpdate(
        user.movements._id,
        {
          $addToSet: {
            movements: {
              _id: new ObjectID(),
              wallet: req.body.wallet,
              operation: req.body.operation,
              tokenContract: req.body.tokenContract,
              tokenSymbol: req.body.tokenSymbol,
              timeStamp: req.body.timeStamp,
              value: req.body.value,
              tokenDecimal: req.body.tokenDecimal,
              gasUsed: req.body.gasUsed,
              gasPrice: req.body.gasPrice,
            },
          },
        },
        { upsert: true, new: true, useFindAndModify: false }
      );
    }

    res.json(updatedMovements);
  } catch (err) {
    res.json({ message: err.message });
  }
});

router.put("/updateWallet", async (req, res) => {
  const user = await Users.findOne({ user: req.body.userID });
  const movements = await Movements.findOne({
    _id: ObjectID(user.movements._id),
  }).exec();
  const result = await movements.movements.filter(
    (item) => item.wallet !== req.body.wallet
  );
  req.body.newMovements.forEach((item, i) => {
    result.push(item);
  });
  movements.movements = result;
  movements.markModified("movements");
  movements.save();
  res.json(movements);
});

router.put("/updateOne", async (req, res) => {
  let indexOfObjectToBeEdited;

  const oldId = req.body.oldMovementId;
  const user = await Users.findOne({ user: req.body.userID });
  //   try {
  //     Contacts.findById({_id: "58a71ec0c80a9a0436ae2fb1"}, function(err,document) {
  //     document.contacts[req.body.indexOfObjectToBeEdited] = req.body.updatedObject
  //     console.log(document)
  //     document.save(function(err) {
  //         return res.json({event:"Updated Contact"})
  //     })
  // })
  const movements = await Movements.findOne({
    _id: ObjectID(user.movements._id),
  }).exec();
  // console.log(await movements.movements[0]._id);
  // console.log(req.body.updatedMovement);
  // console.log(oldId);

  const moveIndex = await movements.movements.findIndex(
    (item) => item._id.toString() === oldId.toString()
  );

  movements.movements[moveIndex] = req.body.updatedMovement;
  movements.markModified("movements");
  movements.save();
  res.json(movements);
  // const oldMovement = await movements.findOne(
  //   {
  //     movements: { _id: ObjectID(req.body.oldMovementId) },
  //   },
  //   function (err, result) {
  //     console.log(result);
  //   }
  // );
  // console.log(oldMovement);
});

router.delete("/delOne", async (req, res) => {
  const user = await Users.findOne({ user: req.body.userID });
  try {
    const movements = await Movements.findByIdAndUpdate(
      user.movements._id,
      {
        $pull: {
          movements: {
            _id: ObjectID(req.body.id),
          },
        },
      },
      { upsert: true, new: true, useFindAndModify: false }
    );
    res.json(movements);
  } catch (err) {
    res.json({ message: err.message });
  }
});

module.exports = router;
