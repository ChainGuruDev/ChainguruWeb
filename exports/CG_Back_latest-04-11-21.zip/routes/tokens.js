const Bottleneck = require("bottleneck");
const express = require("express");
const router = express.Router();
const Tokens = require("../models/Tokens");

const axios = require("axios").default;

const limiter = new Bottleneck({
  minTime: 333,
  maxConcurrent: 3,
});

geckoGetCoinList = async () => {
  try {
    const _url = `https://api.coingecko.com/api/v3/coins/list`;
    const geckolist = await axios.get(_url);
    return geckolist.data;
  } catch (err) {
    res.json({ message: err.message });
  }
};

geckoGetCoinData = async (tokenID) => {
  try {
    const _url = `https://api.coingecko.com/api/v3/coins/${tokenID}`;
    // console.log(_url);
    const geckolist = await axios.get(_url);
    return geckolist.data;
  } catch (err) {
    res.json({ message: err.message });
  }
};

router.get("/", async (req, res) => {
  try {
    const tokens = await Tokens.find();
    res.json(tokens);
  } catch (err) {
    res.json({ message: err.message });
  }
});

router.put("/updateList", async (req, res) => {
  try {
    const tokens = await Tokens.find();
    geckolist = await geckoGetCoinList();
    // console.log(geckolist.length);
    // console.log(await Tokens.countDocuments());

    for (var i = 0; i < geckolist.length; i++) {
      if (
        await Tokens.exists({
          name: geckolist[i].name,
          symbol: geckolist[i].symbol,
        })
      ) {
        // console.log("exists");
      } else {
        // console.log("new Token");
        let newToken = Tokens.create({
          name: geckolist[i].name,
          symbol: geckolist[i].symbol,
          tokenID: geckolist[i].id,
        });
      }
    }
    // console.log("CheckComplete");
    const newTokens = await Tokens.find();

    // const updatedTokens = await Tokens.findOneAndUpdate(
    //   { name: geckolist[i].name },
    //   {
    //     $set: {
    //       tokenID: geckolist[i].id ? geckolist[i].id : "",
    //       name: geckolist[i].name,
    //       symbol: geckolist[i].symbol,
    //     },
    //   },
    //   { upsert: true, new: true, useFindAndModify: false },
    //   async (err, resp) => {
    //     if (!err) {
    //       resp.save(async (err, resp) => {});
    //     }
    //   }
    // );
    res.json(newTokens);
  } catch (err) {
    res.json({ message: err.message });
  }
});

router.put("/updateCat", async (req, res) => {
  try {
    const tokens = await Tokens.find();

    for (var i = 1; i < tokens.length; i++) {
      try {
        // console.log(tokens[i].tokenID);
        if (!tokens[i].categories[0]) {
          try {
            const wrapped = limiter.wrap(geckoGetCoinData);
            const result = await wrapped(tokens[i].tokenID);
            // console.log("WRAPPED RESULT");
            // console.log(result.categories);

            const updatedTokens = await Tokens.findOneAndUpdate(
              { name: tokens[i].name },
              {
                $set: {
                  categories: result.categories,
                },
              },
              { upsert: true, new: true, useFindAndModify: false },
              async (err, resp) => {
                if (!err) {
                  resp.save(async (err, resp) => {});
                }
              }
            );
          } catch (err) {}
        }
      } catch (err) {
        res.json({ message: err.message });
      }
    }
    // console.log("CheckComplete");
    const newTokens = await Tokens.find();

    res.json(newTokens);
  } catch (err) {
    res.json({ message: err.message });
  }
});

router.put("/getTokensbyIDs", async (req, res) => {
  const requestedIDs = req.body.tokenIDs;
  let returnTokens = [];

  for (var i = 0; i < requestedIDs.length; i++) {
    try {
      // console.log(requestedIDs[i]);
      const token = await Tokens.findOne({ tokenID: requestedIDs[i] });
      // console.log(token);
      if (token && !token.categories[0]) {
        try {
          const wrapped = limiter.wrap(geckoGetCoinData);
          const result = await wrapped(token.tokenID);

          const updatedTokens = await Tokens.findByIdAndUpdate(
            token._id,
            {
              $set: {
                categories: result.categories,
              },
            },
            { upsert: true, new: true, useFindAndModify: false },
            async (err, resp) => {
              if (!err) {
                const updatedtoken = await resp;
                returnTokens.push(await updatedtoken);
                resp.save(async (err, resp) => {});
              }
            }
          );
        } catch (err) {
          console.log(err.message);
        }
      } else {
        returnTokens.push(token);
      }
    } catch (err) {
      console.log(err.message);
      // res.json({ message: err.message });
    }
  }
  res.json(returnTokens);
});

router.get("/getTokensbyName", async (req, res) => {
  const requestedIDs = req.body.tokenName;
  let returnTokens = [];

  for (var i = 0; i < requestedIDs.length; i++) {
    try {
      // console.log(requestedIDs[i]);

      const token = await Tokens.findOne({ name: requestedIDs[i] });
      // console.log(await token);
      if (!token.categories[0]) {
        try {
          const wrapped = limiter.wrap(geckoGetCoinData);
          const result = await wrapped(token.name);

          const updatedTokens = await Tokens.findByIdAndUpdate(
            token._id,
            {
              $set: {
                categories: result.categories,
              },
            },
            { upsert: true, new: true, useFindAndModify: false },
            async (err, resp) => {
              if (!err) {
                const updatedtoken = await resp;
                returnTokens.push(await updatedtoken);
                resp.save(async (err, resp) => {});
              }
            }
          );
        } catch (err) {}
      } else {
        returnTokens.push(token);
      }
    } catch (err) {
      res.json({ message: err.message });
    }
  }
  res.json(returnTokens);
});

module.exports = router;
