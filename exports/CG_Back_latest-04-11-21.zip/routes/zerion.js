const express = require("express");
const router = express.Router();
require("dotenv/config");
let io = require("socket.io-client");
const BASE_URL = "wss://api-v4.zerion.io/";

const { authenticateJWT } = require("../extras/verifyJWT.js");

// Bottleneck limiter in case needed
// const Bottleneck = require("bottleneck");
// const limiterZerion = new Bottleneck({
//   minTime: 500,
//   maxConcurrent: 1,
// });

//DEFINE ZERION SOCKETS
const addressSocket = {
  namespace: "address",
  socket: io(`${BASE_URL}address`, {
    transports: ["websocket"],
    timeout: 60000,
    query: {
      api_token: process.env.ZERION_API,
    },
  }),
};

const assetsSocket = {
  namespace: "assets",
  socket: io(`${BASE_URL}assets`, {
    transports: ["websocket"],
    timeout: 60000,
    query: {
      api_token: process.env.ZERION_API,
    },
  }),
};

function verify(request, response) {
  // each value in request payload must be found in response meta
  return Object.keys(request.payload).every((key) => {
    const requestValue = request.payload[key];
    const responseMetaValue = response.meta[key];
    if (typeof requestValue === "object") {
      return JSON.stringify(requestValue) === JSON.stringify(responseMetaValue);
    }
    return responseMetaValue === requestValue;
  });
}

function get(socketNamespace, requestBody) {
  return new Promise((resolve) => {
    const { socket, namespace } = socketNamespace;
    function handleReceive(data) {
      if (verify(requestBody, data)) {
        unsubscribe();
        resolve(data.payload);
      } else {
      }
    }
    const model = requestBody.scope[0];
    function unsubscribe() {
      socket.off(`received ${namespace} ${model}`, handleReceive);
      socket.emit("unsubscribe", requestBody);
    }
    socket.emit("get", requestBody);
    socket.on(`received ${namespace} ${model}`, handleReceive);
  });
}

router.post("/address/assets", async (req, res) => {
  const { address, addresses, asset_codes, currency } = req.body;

  function createData(
    wallet_address,
    asset_code,
    name,
    symbol,
    decimals,
    type,
    icon_url,
    price,
    is_displayable,
    is_verified,
    quantity,
    stats,
    profit_percent
  ) {
    return {
      wallet_address,
      asset_code,
      name,
      symbol,
      decimals,
      type,
      icon_url,
      price,
      is_displayable,
      is_verified,
      quantity,
      stats,
      profit_percent,
    };
  }

  try {
    if (!addresses) {
      res.json("no address");
    }
    if (!currency) {
      res.json("no currency");
    }
    let assetCodesLowerCase = [];
    if (asset_codes) {
      console.log(asset_codes);
      asset_codes.forEach((item, i) => {
        assetCodes.push(item.toLowerCase());
      });
    }
    let formattedData = [];

    for (var i = 0; i < addresses.length; i++) {
      const addressLowerCase = addresses[i].toLowerCase();
      const data = await get(addressSocket, {
        scope: ["assets"],
        payload: {
          address: addresses[i].toLowerCase(),
          currency: currency,
          asset_codes: assetCodesLowerCase,
        },
      });

      Object.entries(data.assets).forEach(([key, value]) => {
        formattedData.push(
          createData(
            addresses[i].toLowerCase(),
            value.asset.asset_code,
            value.asset.name,
            value.asset.symbol,
            value.asset.decimals,
            value.asset.type,
            value.asset.icon_url,
            value.asset.price,
            value.asset.is_displayable,
            value.asset.is_verified,
            value.quantity,
            null,
            null
          )
        );
      });
    }
    res.json(await formattedData);
  } catch (err) {
    console.log(err.message);
    res.json(err.message);
  }
});

router.post("/address/chart", async (req, res) => {
  const { addresses, timeframe, currency } = req.body;

  try {
    if (!addresses) {
      res.json("no address");
    }
    if (!currency) {
      res.json("no currency");
    }
    if (!timeframe) {
      res.json("no timeframe");
    }

    let addressLowerCase = [];
    addresses.forEach((item, i) => {
      addressLowerCase.push(item.toLowerCase());
    });

    const data = await get(addressSocket, {
      scope: ["charts"],
      payload: {
        addresses: addressLowerCase,
        currency: currency,
        charts_type: timeframe,
      },
    });
    let chartInMs = data;
    chartInMs.charts.others.forEach((item, i) => {
      item[0] = item[0] * 1000;
    });

    res.json(chartInMs);
  } catch (err) {
    console.log(err.message);
    res.json(err.message);
  }
});

router.post("/address/portfolio", async (req, res) => {
  try {
    if (!req.body.addresses) {
      res.json("no address");
    }
    if (!req.body.currency) {
      res.json("no currency");
    }
    addressesLowerCase = [];
    req.body.addresses.forEach((item, i) => {
      addressesLowerCase.push(item.toLowerCase());
    });
    const data = get(addressSocket, {
      scope: ["portfolio"],
      payload: {
        addresses: addressesLowerCase,
        currency: req.body.currency,
        portfolio_fields: "all",
      },
    });
    res.json(await data);
  } catch (err) {
    res.json(err.message);
    console.log(err.message);
  }
});

router.post("/assets/stats", async (req, res) => {
  var cancelRequest = false;
  var clientCancelledRequest = "clientCancelledRequest";
  req.on("close", function (err) {
    cancelRequest = true;
  });
  req.on("aborted", function (err) {
    console.log("Abort");
    cancelRequest = true;
  });

  try {
    if (!req.body.address) {
      res.json("no address");
    }
    if (!req.body.currency) {
      res.json("no currency");
    }
    if (!req.body.asset_code) {
      res.json("no assetCode");
    }
    if (Array.isArray(req.body.asset_code)) {
      let allStats = [];
      const timeStart = Date.now();

      for (var i = 0; i < req.body.asset_code.length; i++) {
        if (cancelRequest) {
          console.log("cancelled request");
          throw clientCancelledRequest;
          return;
        }
        console.log(`asset ${i + 1} of ${req.body.asset_code.length}`);
        const data = await get(assetsSocket, {
          scope: ["stats"],
          payload: {
            address: req.body.address.toLowerCase(),
            currency: req.body.currency,
            asset_code: req.body.asset_code[i].toLowerCase(),
          },
        });
        data.asset_code = req.body.asset_code[i];
        data.wallet = req.body.address;
        allStats.push(data);
      }

      console.log(
        `Query of ${req.body.asset_code.length} asset stats finished. Took ${
          (Date.now() - timeStart) / 1000
        } secs`
      );
      res.json(allStats);
    }
  } catch (err) {
    console.log(err);
    if (err !== clientCancelledRequest) {
      console.log(err.message);
      res.json(err.message);
    } else {
      console.log("user cancelled request");
    }
  }
});

router.post("/address/tx", async (req, res) => {
  try {
    const { addresses, currency, query } = req.body;
    if (!req.body.addresses) {
      res.json("no address");
    }
    if (!req.body.currency) {
      res.json("no currency");
    }
    console.log(query);
    if (addresses) {
      let data;
      if (query) {
        data = await get(addressSocket, {
          scope: ["transactions"],
          payload: {
            addresses: addresses,
            currency: currency,
            transactions_search_query: query,
          },
        });
      } else {
        data = await get(addressSocket, {
          scope: ["transactions"],
          payload: {
            addresses: addresses,
            currency: currency,
          },
        });
      }

      res.json(data);
    }
  } catch (err) {
    console.log(err.message);
    res.json(err.message);
  }
});

module.exports = router;
