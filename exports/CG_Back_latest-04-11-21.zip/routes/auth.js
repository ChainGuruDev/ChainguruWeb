const sigUtil = require("eth-sig-util");
const { bufferToHex } = require("ethereumjs-util");
const express = require("express");
const router = express.Router();
const jwt = require("jsonwebtoken");
require("dotenv/config");
const Users = require("../models/Users");

const authorization = (req, res, next) => {
  const cookies = req.cookies;
  if (Object.keys(cookies).length === 0) {
    return res.sendStatus(403);
  }
  try {
    let validCookie = false;
    for (const property in cookies) {
      let data = jwt.verify(
        cookies[property].toString(),
        process.env.JWTPRIVATEREFRESHKEY
      );

      if (req.body.user === data.payload.user) {
        validCookie = true;
        break;
      }
    }

    if (validCookie) {
      console.log("valid cookie found");
      return next();
    } else {
      console.log("not valid cookie");
      res.sendStatus(403);
    }
  } catch (err) {
    // console.log(err.message);
    return res.sendStatus(403);
  }
};

router.use(function (req, res, next) {
  res.header("Access-Control-Allow-Credentials", true);
  next();
});
//Verify Signature and authenticate
router.post("/", async (req, res) => {
  const { signature, publicAddress } = req.body;
  if (!signature || !publicAddress) {
    return res
      .status(400)
      .send({ error: "request should have public address and signature" });
  }
  const userDB = await Users.findOne({ user: publicAddress });
  ////////////////////////////////////////////////////
  // Step 1: Get the user with the given publicAddress
  ////////////////////////////////////////////////////
  if (!userDB) {
    res.status(401).send({
      error: `User with publicAddress ${publicAddress} is not found in database`,
    });
    return null;
  } else {
    if (!(userDB instanceof Users)) {
      // Should not happen, we should have already sent the response
      throw new Error('User is not defined in "Verify digital signature".');
    }

    const msgParams = [
      {
        type: "string", // Any valid solidity type
        name: "Message", // Any string label you want
        value: `Welcome to ChainGuru!

Click "Sign" to sign in. No password needed!
This request will not trigger a blockchain transaction or cost any gas fees.

Your authentication status will be reset after 24 hours.

Wallet address:
${userDB.user}

Nonce:
${userDB.nonce}`,
      },
    ];

    // We now are in possession of msg, publicAddress and signature. We
    // will use a helper from eth-sig-util to extract the address from the signature
    const msgBufferHex = bufferToHex(Buffer.from(msgParams, "utf8"));
    const address = sigUtil.recoverTypedSignatureLegacy({
      sig: signature,
      data: msgParams,
    });

    // The signature verification is successful if the address found with
    // sigUtil.recoverPersonalSignature matches the initial publicAddress
    if (address.toLowerCase() === publicAddress.toLowerCase()) {
      try {
        // Generate long session token and temporary dbAccess token
        // console.log("generating token");
        var issuedAt = Math.floor(Date.now() / 1000);
        const refreshToken = await jwt.sign(
          {
            iat: Math.floor(userDB.nonceCreated / 1000),
            payload: {
              user: userDB.user,
            },
          },
          process.env.JWTPRIVATEREFRESHKEY,
          {
            expiresIn: "24 hours",
          }
        );
        const token = await jwt.sign(
          {
            iat: issuedAt,
            payload: {
              id: userDB.id,
              user: userDB.user,
            },
            nonce: userDB.nonce,
          },
          process.env.JWTPRIVATEKEY,
          {
            expiresIn: "15 minutes",
            issuer: "ChainGuru",
          }
        );
        if (!token) {
          return new Error("Empty token");
        }
        var _token = jwt.verify(token, process.env.JWTPRIVATEKEY);
        var _refreshtoken = jwt.verify(
          refreshToken,
          process.env.JWTPRIVATEREFRESHKEY
        );
        var refreshExpires = new Date(_refreshtoken.exp * 1000);
        const randomUUID = Math.floor(Math.random() * 100000);
        // res.json(token);
        return res
          .cookie(`refresh_token_${randomUUID}`, refreshToken, {
            expires: refreshExpires,
            httpOnly: true,
          })
          .status(200)
          .json({ token: token, tokenExp: _token.exp });
      } catch (err) {
        console.log(err);
        return err.message;
      }
    } else {
      // console.log("Signature verification failed");
      res.status(401).send({
        error: "Signature verification failed",
      });

      return null;
    }
  }
});
// .cookie("refresh_token", refreshToken, {
//   httpOnly: true,
// secure: process.env.NODE_ENV === "production",
// })

router.post("/login", authorization, async (req, res) => {
  const userDB = await Users.findOne({ user: req.body.user });
  try {
    // generate new Short dbAccess token
    var issuedAt = Math.floor(Date.now() / 1000);
    const token = await jwt.sign(
      {
        iat: issuedAt,
        payload: {
          id: userDB.id,
          user: userDB.user,
        },
        nonce: userDB.nonce,
      },
      process.env.JWTPRIVATEKEY,
      {
        expiresIn: "15 minutes",
        issuer: "ChainGuru",
      }
    );
    if (!token) {
      console.log("empty token");
      return new Error("Empty token");
    }
    var _token = jwt.verify(token, process.env.JWTPRIVATEKEY);
    console.log(`logged In ${req.body.user}`);

    return res
      .status(200)
      .json({ token: token, tokenExp: _token.exp, user: userDB.user });
  } catch (err) {
    console.log(err);
    return err.message;
  }
  res.json("logged in");
});

module.exports = router;
