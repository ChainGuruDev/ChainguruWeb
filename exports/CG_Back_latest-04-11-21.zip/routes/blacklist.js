const express = require("express");
const router = express.Router();
const Users = require("../models/Users");
const Blacklist = require("../models/Blacklist");

//GET BLACKLIST
router.get("/", async (req, res) => {
  try {
    const _blacklist = await Blacklist.find();
    res.json(_blacklist);
  } catch (err) {
    res.json({ message: err.message });
  }
});

//GET USER BLACKLIST
router.get("/:userID", async (req, res) => {
  try {
    const updatedUsers = await Users.findOne({ user: req.params.userID });
    if (!updatedUsers.blacklist) {
      console.log("updating blacklist");

      const userBlacklist = await Blacklist.create({
        blacklist: [],
      });
      const updatedUsers = await Users.findOneAndUpdate(
        { user: req.params.userID },
        {
          $set: {
            blacklist: await userBlacklist._id,
          },
        },
        { upsert: true, new: true, useFindAndModify: false },
        async (err, resp) => {
          if (err) {
            console.log(err);
          }
          if (!err) {
            resp.save(async (err, resp) => {
              if (err) {
                console.log(err);
              }
            });
          }
        }
      );
      res.json(updatedUsers.blacklist);
    } else {
      res.json(updatedUsers.blacklist);
    }
  } catch (err) {
    res.json({ message: err.message });
  }
});

//REMOVE TOKEN FROM BLACKLIST
router.delete("/:userID", async (req, res) => {
  const _user = await Users.findOne({ user: req.params.userID });
  try {
    const _updatedBlacklist = await Blacklist.findByIdAndUpdate(
      _user.blacklist._id,
      {
        $pull: {
          tokenIDs: req.body.tokenID,
        },
      },
      { upsert: true, new: true, useFindAndModify: false }
    );
    res.json(_updatedBlacklist);
  } catch (err) {
    res.json({ message: err.message });
  }
});

//ADD TOKEN TO FAVORITES
router.put("/:userID", async (req, res) => {
  const user = await Users.findOne({ user: req.params.userID });
  try {
    const _updatedBlacklist = await Blacklist.findByIdAndUpdate(
      user.blacklist._id,
      {
        $addToSet: {
          tokenIDs: req.body.tokenID,
        },
      },
      { upsert: true, new: true, useFindAndModify: false }
    );
    res.json(_updatedBlacklist);
  } catch (err) {
    res.json({ message: err.message });
  }
});

module.exports = router;
