const express = require("express");
const router = express.Router();
const Users = require("../models/Users");
const Wallets = require("../models/Wallet");
require("dotenv/config");
const axios = require("axios").default;
var dateFormat = require("dateformat");

let _erc20Balance = [
  {
    tokenName: String,
    tokenSymbol: String,
    balance: Number,
    tokenDecimal: Number,
    contractAddress: String,
  },
];

let _movements = [
  {
    type: String,
    timeStamp: Number,
    value: Number,
    price: Array,
  },
];

//UPDATE ERC20 BALANCE
router.put("/movements", async (req, res) => {
  try {
    const etherScanAPI = process.env.ETHERSCAN_API;
    const wallet = await Wallets.findOne({
      wallet: req.body.wallet,
    });
    let newErc20Balance = [];
    for (var i = 0; i < wallet.transactions.length; i++) {
      let tokenIndex;
      if (wallet.transactions[i].tokenSymbol === "UNI-V2") {
        tokenIndex = newErc20Balance.findIndex(
          (token) =>
            token.contractAddress === wallet.transactions[i].contractAddress
        );
      } else if (wallet.transactions[i].tokenSymbol === "SUB") {
        tokenIndex = newErc20Balance.findIndex(
          (token) =>
            token.contractAddress === wallet.transactions[i].contractAddress
        );
      } else {
        tokenIndex = newErc20Balance.findIndex(
          (token) => token.tokenSymbol === wallet.transactions[i].tokenSymbol
        );
      }

      if (wallet.transactions[i].to === req.body.wallet.toLowerCase()) {
        // console.log(`TO TX value >> ${wallet.transactions[i].value}`);
        console.log("BUY TX");
        console.log(wallet.transactions[i]);

        if (tokenIndex != -1) {
          // console.log("PREV BALANCE");
          // console.log(wallet.transactions[i]);
          // console.log(newErc20Balance[tokenIndex]);
          // console.log("PREV BALANCE");
          // console.log(newErc20Balance[tokenIndex]);

          let updatedBalance = newErc20Balance[tokenIndex];
          // console.log(updatedBalance);
          updatedBalance.balance =
            parseFloat(wallet.transactions[i].value) +
            parseFloat(updatedBalance.balance);
          // console.log("NEW BALANCE");
          // console.log(updatedBalance);

          newErc20Balance.splice(tokenIndex, 1, updatedBalance);
        } else {
          const newBalance = {
            tokenName: wallet.transactions[i].tokenName,
            tokenSymbol: wallet.transactions[i].tokenSymbol,
            balance: parseFloat(wallet.transactions[i].value),
            tokenDecimal: wallet.transactions[i].tokenDecimal,
            contractAddress: wallet.transactions[i].contractAddress,
          };
          try {
            newErc20Balance.push(newBalance);
            // console.log("NEW BALANCE");
            // console.log(newBalance);
          } catch (err) {
            console.log(err);
          }
        }
      } else if (
        wallet.transactions[i].from === req.body.wallet.toLowerCase()
      ) {
        console.log("SELL TX");
        console.log(wallet.transactions[i]);

        // console.log(`FROM TX value >> ${wallet.transactions[i].value}`);
        if (tokenIndex != -1) {
          let updatedBalance = newErc20Balance[tokenIndex];
          let newBalance =
            parseFloat(updatedBalance.balance) -
            parseFloat(wallet.transactions[i].value);
          if (newBalance <= 0) {
            newBalance = 0;
          }

          updatedBalance.balance = parseFloat(newBalance);
          newErc20Balance.splice(tokenIndex, 1, updatedBalance);
        } else {
          console.log(
            wallet.transactions[i].tokenSymbol + "not found in balance"
          );

          const newBalance = {
            tokenName: wallet.transactions[i].tokenName,
            tokenSymbol: wallet.transactions[i].tokenSymbol,
            balance: parseFloat(wallet.transactions[i].value),
            tokenDecimal: wallet.transactions[i].tokenDecimal,
            contractAddress: wallet.transactions[i].contractAddress,
          };
          try {
            newErc20Balance.push(newBalance);
            console.log("NEW BALANCE");
            console.log(newBalance);
          } catch (err) {
            console.log(err);
          }
        }
      }
    }
    //console.log(newErc20Balance);
    //console.log("UPDATING BALANCE DB");
    // const updateWallet = await Wallets.findOneAndUpdate(
    //   { wallet: req.body.wallet },
    //   { erc20Balance: newErc20Balance },
    //   { upsert: true, new: true, useFindAndModify: false },
    //   async (error, result) => {
    //     if (!error) {
    //       if (!result) {
    //         result = new Wallet();
    //       }
    //       result.save(async (err, resp) => {
    //         if (!error) {
    //           res.json(result);
    //         } else {
    //           res.json({ message: err.message });
    //         }
    //       });
    //     } else {
    //       res.json({ message: error.message });
    //     }
    //   }
    // );
    res.json(newErc20Balance);
    // res.json(newErc20Balance);
  } catch (err) {
    res.json({ message: err.message });
  }
});

//UPDATE ERC20 BALANCE
router.put("/balance", async (req, res) => {
  try {
    const etherScanAPI = process.env.ETHERSCAN_API;
    const wallet = await Wallets.findOne({
      wallet: req.body.wallet,
    });
    let newErc20Balance = [];
    for (var i = 0; i < wallet.transactions.length; i++) {
      let tokenIndex;
      if (wallet.transactions[i].tokenSymbol === "UNI-V2") {
        // console.log("UNI V2 token");
        tokenIndex = newErc20Balance.findIndex(
          (token) =>
            token.contractAddress === wallet.transactions[i].contractAddress
        );
      } else if (wallet.transactions[i].tokenSymbol === "SUB") {
        tokenIndex = newErc20Balance.findIndex(
          (token) =>
            token.contractAddress === wallet.transactions[i].contractAddress
        );
      } else {
        tokenIndex = newErc20Balance.findIndex(
          (token) => token.tokenSymbol === wallet.transactions[i].tokenSymbol
        );
      }

      if (wallet.transactions[i].to === req.body.wallet.toLowerCase()) {
        // console.log(`TO TX value >> ${wallet.transactions[i].value}`);
        console.log("BUY TX");
        console.log(wallet.transactions[i]);

        if (tokenIndex != -1) {
          // console.log("PREV BALANCE");
          // console.log(wallet.transactions[i]);
          // console.log(newErc20Balance[tokenIndex]);

          // console.log("PREV BALANCE");
          // console.log(newErc20Balance[tokenIndex]);

          let updatedBalance = newErc20Balance[tokenIndex];
          // console.log(updatedBalance);
          updatedBalance.balance =
            parseFloat(wallet.transactions[i].value) +
            parseFloat(updatedBalance.balance);
          // console.log("NEW BALANCE");
          // console.log(updatedBalance);

          newErc20Balance.splice(tokenIndex, 1, updatedBalance);
        } else {
          const newBalance = {
            tokenName: wallet.transactions[i].tokenName,
            tokenSymbol: wallet.transactions[i].tokenSymbol,
            balance: parseFloat(wallet.transactions[i].value),
            tokenDecimal: wallet.transactions[i].tokenDecimal,
            contractAddress: wallet.transactions[i].contractAddress,
          };
          try {
            newErc20Balance.push(newBalance);
            // console.log("NEW BALANCE");
            // console.log(newBalance);
          } catch (err) {
            console.log(err);
          }
        }
      } else if (
        wallet.transactions[i].from === req.body.wallet.toLowerCase()
      ) {
        console.log("SELL TX");
        console.log(wallet.transactions[i]);

        // console.log(`FROM TX value >> ${wallet.transactions[i].value}`);
        if (tokenIndex != -1) {
          let updatedBalance = newErc20Balance[tokenIndex];
          let newBalance =
            parseFloat(updatedBalance.balance) -
            parseFloat(wallet.transactions[i].value);
          if (newBalance <= 0) {
            newBalance = 0;
          }

          updatedBalance.balance = parseFloat(newBalance);
          newErc20Balance.splice(tokenIndex, 1, updatedBalance);
        } else {
          console.log(
            wallet.transactions[i].tokenSymbol + "not found in balance"
          );

          const newBalance = {
            tokenName: wallet.transactions[i].tokenName,
            tokenSymbol: wallet.transactions[i].tokenSymbol,
            balance: parseFloat(wallet.transactions[i].value),
            tokenDecimal: wallet.transactions[i].tokenDecimal,
            contractAddress: wallet.transactions[i].contractAddress,
          };
          try {
            newErc20Balance.push(newBalance);
            console.log("NEW BALANCE");
            console.log(newBalance);
          } catch (err) {
            console.log(err);
          }
        }
      }
    }
    //console.log(newErc20Balance);
    //console.log("UPDATING BALANCE DB");

    //console.log("ADDING ETH BALANCE");
    const _urlEthBalance = `https://api.etherscan.io/api?module=account&action=balance&address=${req.body.wallet}&tag=latest&apikey=${etherScanAPI}`; //${ETHERSCAN_API}
    const ethBal = await axios.get(_urlEthBalance);
    const result = await ethBal.data.result;
    //console.log(result);

    const newBalance = {
      tokenName: "Ethereum",
      tokenSymbol: "eth",
      balance: parseFloat(result),
      tokenDecimal: 18,
      contractAddress: "",
    };
    try {
      const tokenIndex = newErc20Balance.findIndex(
        (token) => token.Name === "Ethereum"
      );
      if (tokenIndex != -1) {
        // console.log("NEW BALANCE");
        // console.log(updatedBalance);
        newErc20Balance.splice(tokenIndex, 1, newBalance);
      } else {
        newErc20Balance.push(newBalance);
      }
      //console.log("NEW BALANCE");
      //console.log(newBalance);
    } catch (err) {
      console.log(err);
    }

    const updateWallet = await Wallets.findOneAndUpdate(
      { wallet: req.body.wallet },
      { erc20Balance: newErc20Balance },
      { upsert: true, new: true, useFindAndModify: false },
      async (error, result) => {
        if (!error) {
          if (!result) {
            result = new Wallet();
          }
          result.save(async (err, resp) => {
            if (!error) {
              res.json(result);
            } else {
              res.json({ message: err.message });
            }
          });
        } else {
          res.json({ message: error.message });
        }
      }
    );

    // res.json(newErc20Balance);
  } catch (err) {
    res.json({ message: err.message });
  }
});

/*
var tx = wallet.transactions.map(async (x) => {
  if (x.to === req.body.wallet.toLowerCase()) {
    console.log("BUY TX");
    if (
      wallet.erc20Balance.some(
        (balance) => balance.tokenName === x.tokenName
      )
    ) {
      console.log(x.tokenSymbol + " found in balance");
      index = wallet.erc20Balance.findIndex(
        (erc20Bal) => erc20Bal.tokenName === x.tokenName
      );
      let newBalance = wallet.erc20Balance[index];
      newBalance.balance += x.value;
      erc20Balance.splice(index, 1, newBalance);
    } else {
      console.log(x.tokenSymbol + " not found in balance");
      newBalanceItem = {
        tokenName: x.tokenName,
        tokenSymbol: x.tokenSymbol,
        balance: x.value,
        tokenDecimal: x.tokenDecimal,
        contractAddress: x.contractAddress.toLowerCase(),
      };

      const updatedWallet = await Wallets.findOneAndUpdate(
        { wallet: req.body.wallet },
        {
          $addToSet: {
            erc20Balance: newBalanceItem,
          },
        },
        { upsert: true, new: true, useFindAndModify: false }
      );
    }
  } else if (x.from === req.body.wallet.toLowerCase()) {
    console.log("SELL TX");
    if (
      wallet.erc20Balance.some(
        (balance) => balance.tokenName === x.tokenName
      )
    ) {
      console.log(x.tokenSymbol + " found in balance");
      index = wallet.erc20Balance.findIndex(
        (erc20Bal) => erc20Bal.tokenName === x.tokenName
      );
      let newBalance = wallet.erc20Balance[index];
      newBalance.balance -= x.value;
      erc20Balance.splice(index, 1, newBalance);
    } else {
      console.log(x.tokenSymbol + " not found in balance");
      newBalanceItem = {
        tokenName: x.tokenName,
        tokenSymbol: x.tokenSymbol,
        balance: x.value,
        tokenDecimal: x.tokenDecimal,
        contractAddress: x.contractAddress.toLowerCase(),
      };

      const updatedWallet = await Wallets.findOneAndUpdate(
        { wallet: req.body.wallet },
        {
          $addToSet: {
            erc20Balance: newBalanceItem,
          },
        },
        { upsert: true, new: true, useFindAndModify: false },
        async (err, resp) => {
          if (!err) {
            resp.save(async (err, resp) => {
              if (!err) {
                console.log("SAVED");
              }
            });
          }
        }
      );
    }
  } else {
    console.log("UNKNOWN TX");
  }
});
*/

//UPDATE WALLET
router.put("/updateOne", async (req, res) => {
  const etherScanAPI = process.env.ETHERSCAN_API;
  const userWallet = req.body.wallet;
  const _url = `https://api.etherscan.io/api?module=account&action=tokentx&address=${req.body.wallet}&startblock=0&endblock=999999999&sort=asc&apikey=${etherScanAPI}`;
  const erc20tx = await axios.get(_url);
  const result = await erc20tx.data.result;

  let _lastUpdate = await Date.now();

  const updateWallet = await Wallets.findOneAndUpdate(
    { wallet: req.body.wallet },
    { transactions: result, lastUpdated: _lastUpdate },
    { upsert: true, new: true, useFindAndModify: false },
    async (error, result) => {
      if (!error) {
        if (!result) {
          result = new Wallet();
        }
        result.save(async (err, resp) => {
          if (!error) {
            res.json(result);
          } else {
            res.json({ message: err.message });
          }
        });
      } else {
        res.json({ message: error.message });
      }
    }
  );
});

//GET ALL WALLETS
router.get("/", async (req, res) => {
  try {
    const wallets = await Wallets.find();
    res.json(wallets);
  } catch (err) {
    res.json({ message: err.message });
  }
});

//GET USER TRANSACTIONS
router.get("/transactions", async (req, res) => {
  try {
    const wallet = await Wallets.findOne({
      wallet: req.body.wallet,
    });

    let txs = wallet.transactions;

    /*  for (var i = 0; i < wallet.transactions.length; i++) {
      const tokenIndex = openPositions.findIndex(
        (token) =>
          token.contractAddress === wallet.transactions[i].contractAddress
      );
      if (wallet.transactions[i].to === req.body.wallet.toLowerCase()) {
        if (tokenIndex != -1) {
          let updatedBalance = openPositions[tokenIndex];
          updatedBalance.balance =
            parseFloat(wallet.transactions[i].value) +
            parseFloat(updatedBalance.balance);

          openPositions.splice(tokenIndex, 1, updatedBalance);
        } else {
          const newPosition = {
            type: "BUY",
            tokenName: wallet.transactions[i].tokenName,
            tokenSymbol: wallet.transactions[i].tokenSymbol,
            balance: parseFloat(wallet.transactions[i].value),
            tokenDecimal: wallet.transactions[i].tokenDecimal,
            contractAddress: wallet.transactions[i].contractAddress,
            timeStamp: wallet.transactions[i].timeStamp,
            gasUsed: wallet.transactions[i].gasUsed,
            gasPrice: wallet.transactions[i].gasPrice,
          };
          try {
            openPositions.push(newPosition);
          } catch (err) {
            console.log(err);
          }
        }
      } else if (
        wallet.transactions[i].from === req.body.wallet.toLowerCase()
      ) {
        console.log(
          dateFormat(wallet.transactions[i].timeStamp * 1000, "dd-mm-yyyy")
        );
        const newPosition = {
          type: "SELL",
          tokenName: wallet.transactions[i].tokenName,
          tokenSymbol: wallet.transactions[i].tokenSymbol,
          balance: parseFloat(wallet.transactions[i].value),
          tokenDecimal: wallet.transactions[i].tokenDecimal,
          contractAddress: wallet.transactions[i].contractAddress,
          timeStamp: wallet.transactions[i].timeStamp,
          gasUsed: wallet.transactions[i].gasUsed,
          gasPrice: wallet.transactions[i].gasPrice,
        };
        try {
          openPositions.push(newPosition);
        } catch (err) {
          console.log(err);
        }
      }
    }
*/
    res.json(txs);
  } catch (err) {
    res.json({ message: err.message });
  }
});

//GET USER WALLETS LIST
router.get("/:userID", async (req, res) => {
  try {
    const users = await Users.findOne({ user: req.params.userID });
    res.json(users.wallets);
  } catch (err) {
    res.json({ message: err.message });
  }
});

//SUBMIT A WALLET AND ADD IT TO USER LIST
router.put("/:userID", async (req, res) => {
  const newWallet = await Wallets.findOneAndUpdate(
    { wallet: req.body.address },
    { wallet: req.body.address },
    { upsert: true, new: true, useFindAndModify: false },
    function (error, result) {
      if (!error) {
        if (!result) {
          result = new Wallet();
        }
        result.save(async (err, resp) => {
          if (!error) {
            const updatedUsers = await Users.findOneAndUpdate(
              { user: req.params.userID },
              {
                $addToSet: {
                  wallets: await result._id,
                },
              },
              { upsert: true, new: true, useFindAndModify: false },
              async (err, resp) => {
                if (!err) {
                  if (!resp) {
                    resp = new Users();
                  }
                  result.save(async (err, resp) => {
                    if (!err) {
                      res.json(updatedUsers);
                    } else {
                      res.json(err.message);
                    }
                  });
                }
              }
            );
          }
        });
      }
    }
  );
});

//REMOVE WALLET FROM USER WALLETs LIST
router.delete("/:userID", async (req, res) => {
  const newWallet = await Wallets.findOne(
    { wallet: req.body.address },
    async (err, result) => {
      if (err) {
        res.json({ message: err.message });
      } else {
        try {
          const updatedUsers = await Users.findOneAndUpdate(
            { user: req.params.userID },
            {
              $pull: {
                wallets: await result._id,
              },
            },
            { new: true, useFindAndModify: false }
          );
          res.json(updatedUsers);
        } catch (err) {
          res.json({ message: err.message });
        }
      }
    }
  );
});

//SUBMIT A WALLET
router.put("/", async (req, res) => {
  const newWallet = await Wallets.findOneAndUpdate(
    { wallet: req.body.address },
    { wallet: req.body.address },
    { upsert: true, new: true, useFindAndModify: false },
    function (error, result) {
      if (!error) {
        if (!result) {
          result = new Wallet();
        }
        result.save(async (err, resp) => {
          if (!error) {
            res.json(result);
          } else {
            res.json({ message: err.message });
          }
        });
      }
    }
  );
});

//REMOVE WALLET FROM DB
router.delete("/", async (req, res) => {
  try {
    const removeWALLET = await Users.deleteOne({ wallet: req.body.address });
    res.json(removeWALLET);
  } catch (err) {
    res.json({ message: err.message });
  }
});

module.exports = router;
