const express = require("express");
const router = express.Router();
const Users = require("../models/Users");
const BlueChips = require("../models/BlueChips");
const { authenticateJWT } = require("../extras/verifyJWT.js");

router.get("/all", async (req, res) => {
  try {
    const blueChips = await BlueChips.find();
    res.json(blueChips);
  } catch (err) {
    res.json({ message: err.message });
  }
});

//GET USER BLUECHIPS
router.post("/", authenticateJWT, async (req, res) => {
  try {
    const user = await Users.findOne({ user: req.body.user });
    let updatedUser;
    if (!user.blueChips) {
      const userBluechips = await BlueChips.create({
        blueChips: [],
      });
      updatedUser = await Users.findOneAndUpdate(
        { user: req.body.user },
        {
          $set: {
            blueChips: await userBluechips._id,
          },
        },
        { upsert: true, new: true, useFindAndModify: false },
        async (err, resp) => {
          if (err) {
            console.log(err);
          }
          if (!err) {
            resp.save(async (err, resp) => {
              if (!err) {
              }
              if (err) {
              }
            });
          }
        }
      );
    }

    if (updatedUser) {
      res.json(updatedUser.blueChips);
    } else {
      res.json(user.blueChips);
    }
  } catch (err) {
    res.json({ message: err.message });
  }
});

//REMOVE TOKEN FROM FAVORITES
router.delete("/del", authenticateJWT, async (req, res) => {
  const user = await Users.findOne({ user: req.body.user });
  try {
    const updatedBlueChips = await BlueChips.findByIdAndUpdate(
      user.blueChips._id,
      {
        $pull: {
          tokenIDs: req.body.tokenID,
        },
      },
      { upsert: true, new: true, useFindAndModify: false }
    );
    res.json(updatedBlueChips);
  } catch (err) {
    res.json({ message: err.message });
  }
});

//ADD TOKEN TO FAVORITES
router.post("/add", authenticateJWT, async (req, res) => {
  const user = await Users.findOne({ user: req.body.user });
  try {
    const updatedBlueChips = await BlueChips.findByIdAndUpdate(
      user.blueChips._id,
      {
        $addToSet: {
          tokenIDs: req.body.tokenID,
        },
      },
      { upsert: true, new: true, useFindAndModify: false }
    );
    res.json(updatedBlueChips);
  } catch (err) {
    res.json({ message: err.message });
  }
});

module.exports = router;
