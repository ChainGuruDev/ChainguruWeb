const express = require("express");
const router = express.Router();
const LongShort = require("../models/LongShort");

const axios = require("axios").default;

geckoGetCurrentPrice = async (tokenID) => {
  try {
    const _url = `https://api.coingecko.com/api/v3/simple/price?ids=${tokenID}&vs_currencies=usd`;
    // console.log(_url);
    const geckolist = await axios.get(_url);
    return geckolist.data;
  } catch (err) {
    res.json({ message: err.message });
  }
};

geckoGetPriceAtTime = async (tokenID, from, to) => {
  try {
    const _url = `https://api.coingecko.com/api/v3/coins/${tokenID}/market_chart/range?vs_currency=usd&from=${from}&to=${to}`;
    // console.log(_url);
    const geckolist = await axios.get(_url);
    // console.log(geckolist.data.prices[0][1]);
    return geckolist.data.prices[0][1];
  } catch (err) {
    res.json({ message: err.message });
  }
};

//GET ALL longShorts
router.get("/all", async (req, res) => {
  try {
    if (req.query.onlyActive === "true") {
      const longShorts = await LongShort.find({ complete: false });
      res.json(longShorts);
    } else {
      const longShorts = await LongShort.find();
      res.json(longShorts);
    }
  } catch (err) {
    res.json({ message: err.message });
  }
});

router.get("/token", async (req, res) => {
  try {
    if (req.query.onlyActive === "false") {
      if (req.query.userID) {
        const tokenPDs = await LongShort.find({
          tokenID: req.query.tokenID,
          user: req.query.userID,
        }).exec();
        res.json(tokenPDs);
      } else {
        const tokenPDs = await LongShort.find({
          tokenID: req.query.tokenID,
        }).exec();
        res.json(tokenPDs);
      }
    } else {
      if (req.query.userID) {
        const tokenPDs = await LongShort.find({
          tokenID: req.query.tokenID,
          complete: false,
          user: req.query.userID,
        }).exec();
        res.json(tokenPDs);
      } else {
        const tokenPDs = await LongShort.find({
          tokenID: req.query.tokenID,
          complete: false,
        }).exec();
        res.json(tokenPDs);
      }
    }
  } catch (err) {
    res.json(err);
  }
});

router.get("/user", async (req, res) => {
  try {
    if (req.query.onlyActive === "true") {
      const allUserPDs = await LongShort.find({
        user: req.query.userID,
        complete: false,
      }).exec();
      res.json(allUserPDs);
    } else {
      const userActivePDs = await LongShort.find({
        user: req.query.userID,
      }).exec();
      res.json(userActivePDs);
    }
  } catch (err) {
    res.json(err);
  }
});

//CREATE NEW LongShort
//Check if user has a running LongShort with current tokenID,
// else create a new one;
router.put("/new", async (req, res) => {
  const userLongShort = await LongShort.find({
    user: req.body.user,
    tokenID: req.body.tokenID,
  }).exec();
  const tokenID = req.body.tokenID;
  const currentPrice = await geckoGetCurrentPrice(tokenID);
  const newPD = new LongShort({
    user: req.body.user,
    tokenID: req.body.tokenID,
    vote: req.body.vote,
    priceStart: currentPrice[tokenID].usd,
    // voteEnding: Date.now() + 120 * 1000, // 60 seconds from now for test reasons
    // voteEnding: Date.now() + 12 * 60 * 60 * 1000, // 24 hours from now
    voteEnding: Date.now() + 24 * 60 * 60 * 1000, // 24 hours from now
  });

  if (userLongShort.length != 0) {
    if (userLongShort[userLongShort.length - 1].complete === false) {
      res.json(userLongShort[userLongShort.length - 1]);
    } else {
      newPD.save().then(() => res.json(newPD));
    }
  } else {
    newPD.save().then(() => res.json(newPD));
  }
});

router.put("/checkResult", async (req, res) => {
  try {
    const date = new Date(Date.now());

    //Find latest user P&D for tokenID
    const longShort = await LongShort.find({
      user: req.body.user,
      tokenID: req.body.tokenID,
      complete: false,
    }).exec();
    if (longShort.length != 0) {
      //if there's an active one check for currentTime > voteEnding
      const oldPD = longShort[longShort.length - 1];
      if (date.getTime() > oldPD.voteEnding.getTime()) {
        // console.log("new time");
        //reformat TIME IN SECONDS not mili for coingecko request
        shortFromTime =
          (oldPD.voteEnding.getTime() - (oldPD.voteEnding.getTime() % 1000)) /
          1000;
        shortToTime = (date.getTime() - (date.getTime() % 1000)) / 1000;
        //Query price data from coingecko
        const priceEnd = await geckoGetPriceAtTime(
          req.body.tokenID,
          shortFromTime,
          shortToTime
        );
        // console.log(priceEnd);
        const updatedPD = await LongShort.findByIdAndUpdate(
          oldPD.id,
          {
            $set: {
              priceStart: oldPD.priceStart,
              priceEnd: priceEnd,
              result:
                priceEnd > oldPD.priceStart
                  ? oldPD.vote
                    ? true
                    : false
                  : oldPD.vote
                  ? false
                  : true,
              complete: true,
            },
          },
          {
            upsert: true,
            new: true,
            useFindAndModify: false,
          }
        );
        res.json(updatedPD);
      } else {
        res.json({ error: "voting time not complete" });
      }
    } else {
      res.json(longShort);
    }
  } catch (err) {
    res.json({ message: err.message });
  }
});

module.exports = router;
