const express = require("express");
const router = express.Router();
const Users = require("../models/Users");
const Wallet = require("../models/Wallet");
const Favorites = require("../models/Favorites");
const Movements = require("../models/Movements");
const Blacklist = require("../models/Blacklist");
const BlueChips = require("../models/BlueChips");
const jwt = require("jsonwebtoken");
require("dotenv/config");
//PURGE DB
/*
router.purge("/", async (req, res) => {
  try {
    await Users.collection.drop();
    await Wallet.collection.drop();
    await Favorites.collection.drop();
    await Movements.collection.drop();
    await Blacklist.collection.drop();
    res.json({ message: "DB Cleared" });
  } catch (err) {
    res.json({ message: err.message });
  }
});
*/

const authenticateJWT = (req, res, next) => {
  const authHeader = req.headers.authorization;
  if (authHeader) {
    const token = authHeader.split(" ")[1];
    jwt.verify(token, process.env.JWTPRIVATEKEY, (err, data) => {
      if (err) {
        console.log(err);
        return res.sendStatus(403);
      }
      const reqUser = req.params.userID ? req.params.userID : req.body.user;
      if (reqUser === data.payload.user) {
        // console.log("valid access token");
        next();
      } else {
        // console.log("not a valid access token for this user");
        res.sendStatus(401);
      }
    });
  } else {
    res.sendStatus(401);
  }
};

//GET ALL Users
router.get("/", async (req, res) => {
  try {
    const users = await Users.find();
    let userList = [];
    users.forEach((item, i) => {
      userList.push(item.user);
    });

    res.json(userList);
  } catch (err) {
    res.json({ message: err.message });
  }
});

//Verify Signature and authenticate
router.post("/auth", async (req, res) => {
  const users = await Users.findOne({ user: req.body.user });
  console.log(users);
});
//get Leaderboard
router.get("/leaderboard", async (req, res) => {
  try {
    const users = await Users.find();
    let userList = [];
    users.forEach((item, i) => {
      if (item.experiencePoints) {
        userList.push({
          avatar: item.avatar,
          experiencePoints: item.experiencePoints,
          nickname: item.nickname,
          minigames: item.minigames,
        });
      }
    });

    let leaderboard = userList.sort(function (a, b) {
      if (a.experiencePoints > b.experiencePoints) {
        return -1;
      }
      if (a.experiencePoints < b.experiencePoints) {
        return 1;
      }
      // a must be equal to b
      return 0;
    });

    res.json(leaderboard);
  } catch (err) {
    res.json({ message: err.message });
  }
});

//GET USER DATA
//Checks if user exists and returns current nonce, nonce creation and user
router.get("/:userID", async (req, res) => {
  try {
    const user = await Users.findOne({ user: req.params.userID });
    // const nonceValidTil =
    // Number(new Date(user.nonceCreated)) + 24 * 60 * 60 * 1000;

    //5 minutes for testing purposes
    const nonceValidTil = Number(new Date(user.nonceCreated)) + 60 * 60 * 1000;

    // check if current nonce is still valid
    if (Date.now() > nonceValidTil) {
      // console.log("nonce expired, creating new one");
      const newNonce = Math.floor(Math.random() * 10000000);
      user.nonce = newNonce;
      user.nonceCreated = Date.now();
      user.save();
    }

    // if user exists return data for signature create/verify

    if (user) {
      res.json({
        user: user.user,
        nonce: user.nonce,
        nonceCreated: user.nonceCreated,
      });
    } else {
      res.json({ message: "no user found" });
    }
  } catch (err) {
    console.log(err.message);
    res.json({ message: err.message });
  }
});

router.post("/data", authenticateJWT, async (req, res) => {
  try {
    // console.log(req.body.user);
    const users = await Users.findOne({ user: req.body.user });
    // console.log(users);
    let updatedUsers;
    if (!users.favorites) {
      console.log("updating favorites");

      const userFavorites = await Favorites.create({
        favorites: [],
      });
      updatedUsers = await Users.findOneAndUpdate(
        { user: req.body.user },
        {
          $set: {
            favorites: await userFavorites._id,
          },
        },
        { upsert: true, new: true, useFindAndModify: false },
        async (err, resp) => {
          if (err) {
            console.log(err);
          }
          if (!err) {
            resp.save(async (err, resp) => {
              if (!err) {
              }
              if (err) {
              }
            });
          }
        }
      );
    }
    if (!users.blueChips) {
      console.log("updating bluechips");

      const userBluechips = await BlueChips.create({
        blueChips: [],
      });
      updatedUsers = await Users.findOneAndUpdate(
        { user: req.body.user },
        {
          $set: {
            blueChips: await userBluechips._id,
          },
        },
        { upsert: true, new: true, useFindAndModify: false },
        async (err, resp) => {
          if (err) {
            console.log(err);
          }
          if (!err) {
            resp.save(async (err, resp) => {
              if (!err) {
              }
              if (err) {
              }
            });
          }
        }
      );
    }
    if (!users.blacklist) {
      console.log("updating blacklist");

      const userBlacklist = await Blacklist.create({
        blacklist: [],
      });
      updatedUsers = await Users.findOneAndUpdate(
        { user: req.body.user },
        {
          $set: {
            blacklist: await userBlacklist._id,
          },
        },
        { upsert: true, new: true, useFindAndModify: false },
        async (err, resp) => {
          if (err) {
            console.log(err);
          }
          if (!err) {
            resp.save(async (err, resp) => {
              if (!err) {
              }
              if (err) {
              }
            });
          }
        }
      );
    }

    if (updatedUsers) {
      res.json(updatedUsers);
    } else {
      res.json(users);
    }
  } catch (err) {
    console.log(err.message);
    res.json({ message: err.message });
  }
});

//CREATE USER
router.put("/:userID", async (req, res) => {
  const userWallet = await Wallet.findOneAndUpdate(
    { wallet: req.params.userID },
    { wallet: req.params.userID },
    { upsert: true, new: true, useFindAndModify: false },
    function (error, result) {
      if (!error) {
        if (!result) {
          result = new Wallet();
        }
        result.save(async (err, resp) => {
          if (!error) {
            const updatedUsers = await Users.findOneAndUpdate(
              { user: req.params.userID },
              {
                $addToSet: {
                  wallets: await result._id,
                },
              },
              { upsert: true, new: true, useFindAndModify: false },
              async (err, resp) => {
                if (!err) {
                  if (!resp) {
                    resp = new Users();
                  }
                  result.save(async (err, resp) => {
                    if (!err) {
                    }
                  });
                }
              }
            );
            if (!updatedUsers.favorites) {
              console.log("updating favorites");

              const userFavorites = await Favorites.create({
                favorites: [],
              });
              const updatedUsers = await Users.findOneAndUpdate(
                { user: req.params.userID },
                {
                  $set: {
                    favorites: await userFavorites._id,
                  },
                },
                { upsert: true, new: true, useFindAndModify: false }
              );
            }
            if (!users.blueChips) {
              console.log("updating bluechips");

              const userBluechips = await BlueChips.create({
                blueChips: [],
              });
              updatedUsers = await Users.findOneAndUpdate(
                { user: req.params.userID },
                {
                  $set: {
                    blueChips: await userBluechips._id,
                  },
                },
                { upsert: true, new: true, useFindAndModify: false },
                async (err, resp) => {
                  if (err) {
                    console.log(err);
                  }
                  if (!err) {
                    resp.save(async (err, resp) => {
                      if (!err) {
                      }
                      if (err) {
                      }
                    });
                  }
                }
              );
            }
            if (!updatedUsers.blacklist) {
              console.log("updating favorites");

              const userBlacklist = await Blacklist.create({
                blacklist: [],
              });
              const updatedUsers = await Users.findOneAndUpdate(
                { user: req.params.userID },
                {
                  $set: {
                    blacklist: await userBlacklist._id,
                  },
                },
                { upsert: true, new: true, useFindAndModify: false }
              );
            }
            res.json(updatedUsers);
          }
        });
      }
    }
  );
});

//set new Nickname
router.put("/:userID/setNickname", authenticateJWT, async (req, res) => {
  if (req.body.newNickname) {
    if (req.body.newNickname.length <= 16) {
      const nicknameUsed = await Users.findOne({
        nickname: req.body.newNickname,
      });
      if (nicknameUsed) {
        res.json({ message: "nickname already in use", error: true });
      } else {
        const updatedUsers = await Users.findOneAndUpdate(
          { user: req.params.userID },
          {
            $set: {
              nickname: req.body.newNickname,
            },
          },
          { upsert: true, new: true, useFindAndModify: false },
          function (error, result) {
            res.json(result);
          }
        );
      }
    } else {
      res.json({
        message: "nickname must be 16 characters or less",
        error: true,
      });
    }
  } else {
    res.json({
      message: "enter a valid nickname",
      error: true,
    });
  }
});

//set new Avatar
router.put("/:userID/setAvatar", authenticateJWT, async (req, res) => {
  if (req.body.newAvatar) {
    const updatedUsers = await Users.findOneAndUpdate(
      { user: req.params.userID },
      {
        $set: {
          avatar: req.body.newAvatar,
        },
      },
      { upsert: true, new: true, useFindAndModify: false },
      function (error, result) {
        res.json(result);
      }
    );
  } else {
    res.json({
      message: "newAvatar Required",
      error: true,
    });
  }
});

//GET user Wallet nickname
router.get("/:userID/walletnick", async (req, res) => {
  try {
    const users = await Users.findOne({ user: req.params.userID });
    res.json(users.walletNicknames);
  } catch (err) {
    console.log(err.message);
    res.json({ message: err.message });
  }
});

//PUT user Wallet Nickname
// router.put("/:userID/walletnick", async (req, res) => {
//   try {
//     const user = await Users.findOne({ user: req.params.userID });
//     if (user.walletNicknames.some((e) => e.wallet === req.body.wallet)) {
//       const oldNicknames = user.walletNicknames;
//       console.log(oldNicknames);
//       for (var i = 0; i < oldNicknames.length; i++) {
//         if (oldNicknames[i].wallet === req.body.wallet) {
//           oldNicknames[i].nickname = req.body.nick;
//         }
//       }
//       const updatedUser = await Users.findByIdAndUpdate(
//         user._id,
//         {
//           $set: {
//             walletNicknames: oldNicknames,
//           },
//         },
//         { upsert: true, new: true, useFindAndModify: false },
//         async (error, result) => {
//           if (!error) {
//             result.save(async (err, resp) => {
//               if (!error) {
//                 res.json(result.walletNicknames);
//               } else {
//                 res.json({ message: err.message });
//               }
//             });
//           } else {
//             res.json({ message: error.message });
//           }
//         }
//       );
//     } else {
//       console.log({ message: "wallet is not in KVP" });
//       const updatedMovements = await Users.findByIdAndUpdate(
//         user._id,
//         {
//           $addToSet: {
//             walletNicknames: [
//               {
//                 wallet: req.body.wallet,
//                 nickname: req.body.nick,
//               },
//             ],
//           },
//         },
//         { upsert: true, new: true, useFindAndModify: false },
//         async (error, result) => {
//           if (!error) {
//             result.save(async (err, resp) => {
//               if (!error) {
//                 res.json(result.walletNicknames);
//               } else {
//                 res.json({ message: err.message });
//               }
//             });
//           } else {
//             res.json({ message: error.message });
//           }
//         }
//       );
//     }
//   } catch (err) {
//     console.log(err.message);
//     res.json({ message: err.message });
//   }
// });

//DELETE
router.put("/:userID/walletnickRemove", authenticateJWT, async (req, res) => {
  try {
    const user = await Users.findOne({ user: req.params.userID });
    const oldNicknames = user.walletNicknames;
    for (var i = 0; i < oldNicknames.length; i++) {
      if (oldNicknames[i].wallet === req.body.wallet) {
        oldNicknames.pop(i);
      }
    }
    const updatedUser = await Users.findByIdAndUpdate(
      user._id,
      {
        $set: {
          walletNicknames: oldNicknames,
        },
      },
      { upsert: true, new: true, useFindAndModify: false },
      async (error, result) => {
        if (!error) {
          result.save(async (err, resp) => {
            if (!error) {
              res.json(result.walletNicknames);
            } else {
              res.json({ message: err.message });
            }
          });
        } else {
          res.json({ message: error.message });
        }
      }
    );
  } catch (err) {
    console.log(err.message);
    res.json({ message: err.message });
  }
});

//REMOVE USER FROM DB wait til only admin can delete
// router.delete("/:userID", async (req, res) => {
//   try {
//     const removeUser = await Users.deleteOne({
//       user: req.params.userID,
//     });
//     res.json(removeUser);
//   } catch (err) {
//     res.json({ message: err.message });
//   }
// });

module.exports = router;
