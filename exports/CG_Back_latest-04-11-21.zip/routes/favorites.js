const express = require("express");
const router = express.Router();
const Users = require("../models/Users");
const Favorites = require("../models/Favorites");
const { authenticateJWT } = require("../extras/verifyJWT.js");

//GET FAVORITES
router.get("/", async (req, res) => {
  try {
    const fav = await Favorites.find();
    res.json(fav);
  } catch (err) {
    res.json({ message: err.message });
  }
});

//GET USER FAVORITES
router.get("/:userID", authenticateJWT, async (req, res) => {
  try {
    const users = await Users.findOne({ user: req.params.userID });
    res.json(users.favorites);
  } catch (err) {
    res.json({ message: err.message });
  }
});

//REMOVE TOKEN FROM FAVORITES
router.delete("/:userID", authenticateJWT, async (req, res) => {
  const user = await Users.findOne({ user: req.params.userID });
  try {
    const updatedFavorites = await Favorites.findByIdAndUpdate(
      user.favorites._id,
      {
        $pull: {
          tokenIDs: req.body.tokenID,
        },
      },
      { upsert: true, new: true, useFindAndModify: false }
    );
    res.json(updatedFavorites);
  } catch (err) {
    res.json({ message: err.message });
  }
});

//ADD TOKEN TO FAVORITES
router.put("/:userID", authenticateJWT, async (req, res) => {
  const user = await Users.findOne({ user: req.params.userID });
  try {
    const updatedFavorites = await Favorites.findByIdAndUpdate(
      user.favorites._id,
      {
        $addToSet: {
          tokenIDs: req.body.tokenID,
        },
      },
      { upsert: true, new: true, useFindAndModify: false }
    );
    res.json(updatedFavorites);
  } catch (err) {
    res.json({ message: err.message });
  }
});

module.exports = router;
